You are reading a finished email sequence the way its recipient will: in order, over days, as one
person with the relationship established in the supplied context. Do not assume they signed
up, bought, or received unsolicited mail when that relationship is unknown.

Every one of these emails has already been judged on its own and passed. That is not what you are
here for. You are looking for the failures that only exist between them — the ones nobody can see
from inside a single draft.

# Who receives these

{{ reader }}

# The user's original request and recipient conditions

{{ user_request }}

This outranks a proposed arc or brief when deciding which recipient events are established.

# What the campaign promised

{{ promise }}

# The arc it was designed to have

{{ arc }}

# What each email was supposed to do

{{ plan }}

# The sequence

{{ sequence }}

# What to judge

**escalates** — does each email move the reader somewhere the last one did not? A sequence that
restates its promise five times in five registers has not escalated; it has repeated. Look for
the thing that changes between emails: what the reader now knows, believes, or feels the cost of.
False when two adjacent emails are interchangeable in order.

**promise_is_consistent** — is every email arguing for the same promise, or has the campaign
quietly become about something else by email four? Drift usually happens late, when the strongest
material is spent and an email reaches for a new angle to have something to say.

**each_stands_alone** — assume the reader missed every previous email, because most of them did.
Does any email depend on one before it? A back-reference ("as I mentioned", "following up on my
last note"), an unexplained term introduced earlier, a joke whose setup was in email two — each of
those turns a missed email into a confusing one.

Also check dependencies on an earlier action. Sending a draft, placing an email later in
the sequence, or waiting a day does not establish an open, click, signup, purchase, upload
or completed run. "Open your finished report" fails this test if no supplied audience
condition establishes a finished run. Require conditional wording or supported creation
steps for readers who have not acted, using the same destination. Do not undo an explicit
user-supplied behaviour trigger. A proposed arc or brief alone cannot establish one.

**Does the reader ever learn what this is?** Read the sequence as somebody who opened exactly one
of these, and check each email separately: can they say what is being sold from that email alone?
An email that leans on a previous one to establish what the product is has failed the same test
as one with a back-reference in it, and it fails it more quietly — there is no phrase to point
at, only a stranger who reaches the link with nothing to attach it to. Note the position of any
email that only makes sense to somebody who read an earlier one.

**Does the sequence advance its actual goal?** Check for useful progression: a clearer buying
decision, successful activation, a next task, or another outcome the campaign was asked to serve.
A replacement campaign may explain a limitation of the current approach. Do not require that
argument in onboarding or invent it when the product's direct benefit already earns the action.
Flag repeated assertions that add no useful reason or ability to act.

**notes** — one entry per problem, attached to the `position` of the email that should change.
Prefer fixing the later email of a pair: the earlier one has already earned its place, and the
reader met it first. `problem` says what is wrong across the sequence; `fix` says what that
email's rewrite has to achieve, without writing the copy.

Repeated phrases, repeated opening lines and duplicate subject lines have already been found
automatically and are already being fixed — do not spend notes on them.

**summary** — one sentence on whether this sequence does its job.

Report only real problems. A sequence that works should come back with no notes at all: sending
a working sequence back for another round costs the user real money and usually makes the copy
blander, because a rewrite of something that already lands mostly removes what made it land.
