from dataclasses import dataclass

from app.schemas.linkedin import LinkedInChannel


@dataclass(frozen=True)
class CampaignRequest:
    """What the user asked for, in their own words, plus the context around it.

    `request` is the contract and is rendered verbatim at the top of every
    prompt in the run. That one habit is what makes "3 emails" produce three
    emails instead of a generic campaign, and it survives the redesign
    unchanged - it was the best idea in the original system.

    Everything else here is context the knowledge artifacts usually know
    better. It is kept because a user typing "we're targeting agencies, not
    freelancers" in the campaign form is stating something no crawl can
    discover, and that must outrank what the compiler inferred.
    """

    name: str
    request: str
    product_description: str = ""
    product_url: str | None = None
    target_market: str | None = None
    goals: str | None = None
    #: Who the email is from. A person, and their job.
    #:
    #: Small field, real conversion. The writer is told it does not know the
    #: sender's name, so every email in the system signs off as "- the X team",
    #: which is the signature of a marketing department and is read as one. A
    #: name and a role are one form field the user fills once, and they change
    #: what the reader thinks they are holding: a mail from a person who could
    #: be replied to, rather than a broadcast.
    sender_name: str = ""
    sender_role: str = ""
    #: Set when this campaign's deliverable is a LinkedIn message instead of
    #: email. Structured rather than inferred: which channel a campaign writes
    #: for decides the contract, and a contract read out of prose is a
    #: contract a sentence about LinkedIn can change by accident.
    channel: LinkedInChannel | None = None
    #: Where the button goes, when the user fixed it. The renderer always
    #: honours it, so the plan has to as well: a strategy that never saw it
    #: chose "View live demo" from the offer sheet while the button it labelled
    #: opened the goal-conversions guide the user had picked.
    cta_url: str | None = None

    @property
    def sender(self) -> str:
        if self.sender_name and self.sender_role:
            return f"{self.sender_name}, {self.sender_role}"
        return self.sender_name or self.sender_role

    def render_context(self) -> str:
        lines = [f"Campaign: {self.name}"]
        if self.product_description:
            lines.append(f"What the user says the product is: {self.product_description}")
        if self.target_market:
            lines.append(f"Who the user says they are targeting: {self.target_market}")
        if self.goals:
            lines.append(f"What the user wants out of it: {self.goals}")
        if self.sender:
            lines.append(f"Who it comes from: {self.sender}")
        if self.cta_url:
            lines.append(
                f"Where the call to action links, fixed by the user: {self.cta_url}. Every "
                "email's ask must describe what the reader finds at that page; any other "
                "action has no button to land on."
            )
        if self.channel is not None:
            lines.append(
                f"Channel: one LinkedIn {self.channel.kind} to {self.channel.recipient_name} "
                f"({self.channel.recipient_url}), written in {self.channel.language}."
            )
            if self.channel.confirmed_context:
                lines.append(
                    "What the user has checked about this recipient: "
                    f"{self.channel.confirmed_context}"
                )
        return "\n".join(lines)
