"""The campaign pipeline: three phases, orchestrated in code.

There is no LLM director any more, and removing it is the central change of
this design. The old one spent a model call per step deciding which specialist
to run next, out of a catalog whose correct order was fixed by data
dependencies and was already written down, in prose, inside the director's own
prompt. An LLM interpreting an if-statement is not orchestration; it is an
expensive, stochastic re-derivation of a decision that was never open. It also
came with its own failure mode - invalid decisions - and the machinery to
survive that failure mode was a meaningful fraction of the old codebase.

What is left is a state machine. Knowledge is compiled (or reused), a brief is
written, each email is crafted, the sequence is read as a sequence, and the
result is checked against the contract that was parsed out of the user's
sentence before anything ran. Every model call in the run either distills
knowledge, decides strategy, writes copy, or judges copy. None of them route.

The guards from the old director are kept in spirit: budgets and deadlines are
checked between steps, never mid-call, so a stopped run always leaves a
consistent, fully persisted state rather than a half-written email.
"""

import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Literal

from app.knowledge.artifacts import KnowledgeArtifacts, Segment
from app.knowledge.compiler import ROLE_ID as COMPILER_ROLE
from app.knowledge.compiler import KnowledgeCompiler
from app.knowledge.corpus import SourceCorpus
from app.knowledge.ledger import EvidenceIndex
from app.knowledge.store import StoredArtifacts
from app.market.demand import DemandMap
from app.market.material_research import (
    ROLE_ID as MATERIAL_RESEARCH_ROLE,
)
from app.market.material_research import (
    MaterialRecovery,
    MaterialResearcher,
    apply_recovery,
    cited_recovery,
    existing_recovery,
)
from app.market.positioning import PositioningMap
from app.marketing.briefs import CampaignBrief
from app.marketing.cancellation import CancellationToken
from app.marketing.contract import (
    DeliverableContract,
    DeliverableKind,
    check_contract,
    linkedin_contract,
    parse_contract,
)
from app.marketing.craft import CraftLoop, EmailOutcome
from app.marketing.critic import ConversionCritic
from app.marketing.email_copy import Email
from app.marketing.exceptions import CampaignError, CraftError
from app.marketing.intelligence import (
    AudienceResolution,
    CampaignIntelligence,
    CampaignIntelligenceBundle,
    CampaignIntelligenceTrace,
    DossierPosture,
    attach_selected_dossier_objection,
)
from app.marketing.linkedin import ROLE_ID as LINKEDIN_WRITER_ROLE
from app.marketing.linkedin import write_message
from app.marketing.observer import RunObserver
from app.marketing.policy import ExecutionPolicy
from app.marketing.preflight import ProofPosture, assess
from app.marketing.reader import PULL_THRESHOLD, BlindReader, personas_for
from app.marketing.report import CampaignReport, EmailReportLine, ReaderVerdict
from app.marketing.request import CampaignRequest
from app.marketing.sequence import ROLE_ID as SEQUENCE_ROLE
from app.marketing.sequence import SequenceReport, SequenceReviewer
from app.marketing.strategist import ROLE_ID as STRATEGIST_ROLE
from app.marketing.strategist import Strategist
from app.marketing.subject_lines import SubjectBakeOff
from app.marketing.substantiation import assess_text
from app.marketing.tournament import PreferenceJudge
from app.marketing.writer import EmailWriter
from app.runtime.exceptions import ModelRuntimeError, OutputValidationError
from app.runtime.model_session import ModelSession, Usage

logger = logging.getLogger("marketingos.marketing")

RunStatus = Literal[
    "completed",
    "degraded",
    "failed",
    "cancelled",
    "timed_out",
    "budget_exhausted",
    "provider_unavailable",
    "needs_input",
]

_GUARD_MESSAGES: dict[str, str] = {
    "cancelled": "Cancelled by user request.",
    "timed_out": "Execution exceeded its maximum run time.",
    "budget_exhausted": "Execution exceeded its token budget.",
    "provider_unavailable": (
        "The model stopped answering and did not come back after several attempts. "
        "Everything finished before that point is below."
    ),
}


def _intelligence_message(intelligence: CampaignIntelligence) -> str:
    trace = intelligence.trace
    if trace.audience_resolution_status is AudienceResolution.AMBIGUOUS:
        return "Researched audience match is ambiguous; using the legacy audience fallback"
    if trace.audience_resolution_status is AudienceResolution.MISSING:
        return "No matching Audience Research; using the legacy audience fallback"
    if trace.dossier_status is DossierPosture.CURRENT:
        return "Researched audience and current Relevance Dossier loaded"
    if trace.dossier_status is DossierPosture.STALE:
        return (
            "Researched audience loaded; stale Relevance Dossier is advisory ("
            + ", ".join(trace.stale_reasons)
            + ")"
        )
    return "Researched audience loaded; no Relevance Dossier, using legacy relevance fallback"


class KnowledgeGateway(ABC):
    """Where the pipeline gets a business's material and compiled knowledge.

    An interface rather than a database call so the pipeline can be run - and
    tested - without one. The orchestrator implements it over the artifact
    store; a test implements it over a list of strings.
    """

    @abstractmethod
    def corpus(self) -> SourceCorpus: ...

    @abstractmethod
    def fingerprint(self) -> str: ...

    @abstractmethod
    def load(self) -> StoredArtifacts | None: ...

    @abstractmethod
    def save(self, artifacts: KnowledgeArtifacts, fingerprint: str) -> StoredArtifacts: ...

    def prior_learnings(self) -> str:
        """What earlier campaigns for this business found out. Empty is fine."""
        return ""

    def positioning(self) -> PositioningMap | None:
        """Where this business stands against its market, if anybody has read it.

        On the gateway rather than passed into `run` because it is the same
        kind of thing as the compiled artifacts: it belongs to the business,
        it outlives the campaign, and a pipeline running without a database
        should be able to answer "nobody has scanned this market" without a
        caller having to say so. None is a first-class answer here - see
        `PositioningMap.render_for_strategy`, which tells the strategist that
        it is writing blind rather than that the field is empty.
        """
        return None

    def demand(self) -> DemandMap | None:
        """Who the market says would buy this, if anybody has mapped it.

        Beside `positioning` and for the same reasons: it belongs to the
        business, it outlives the campaign, and None is a first-class answer -
        see `DemandMap.render_for_strategy`, which tells the strategist it is
        working from the company's own idea of its buyer rather than pretending
        the question was never asked.
        """
        return None

    def audience_choice(self) -> str:
        """The mapped segment this campaign was pointed at, or "" for none.

        Separate from `demand` because they answer different questions: one is
        what exists, the other is what this run was asked to do with it. The
        chosen segment is *already* at the head of the artifacts by the time
        the pipeline sees them (see `app.market.store.merge_audience`), so
        nothing downstream needs this - the strategist does, because the
        contrast between the buyer it was given and the ones it was not is
        what makes the choice legible.
        """
        return ""

    def campaign_intelligence(
        self, artifacts: KnowledgeArtifacts
    ) -> CampaignIntelligenceBundle | None:
        """Verified context for the selected audience, if this gateway has one.

        Database-free and historical gateways inherit the no-op. A run
        without a brand or explicit audience therefore takes exactly the old
        path and performs no market-intelligence lookup.
        """
        return None

    def commit_recovered_material(
        self, recovery: MaterialRecovery, artifacts: KnowledgeArtifacts
    ) -> StoredArtifacts | None:
        """Persist automatically verified sources when this gateway can.

        Database-free and historical gateways keep the enrichment inside the
        current run.  The application gateway stores the exact fetched pages
        and the enriched artifact set so the next campaign does not rediscover
        the same fact.
        """
        return None


@dataclass
class CampaignRunResult:
    status: RunStatus = "failed"
    artifacts: KnowledgeArtifacts | None = None
    brief: CampaignBrief | None = None
    outcomes: list[EmailOutcome] = field(default_factory=list)
    sequence: SequenceReport | None = None
    report: CampaignReport = field(default_factory=CampaignReport)
    usage: Usage = field(default_factory=Usage)
    abort_reason: str | None = None
    intelligence: CampaignIntelligenceTrace | None = None
    #: The finished LinkedIn message, on a run whose channel asked for one -
    #: body, character count and the limit it was written to. Its own field
    #: rather than an `EmailOutcome` with the subject left blank: it was never
    #: read cold and never duelled, and borrowing a shape that carries both
    #: would report scores nobody measured.
    message: dict | None = None

    @property
    def emails(self) -> list[Email]:
        return [outcome.email for outcome in self.outcomes]

    @property
    def delivered(self) -> bool:
        return bool(self.outcomes) or self.message is not None

    @property
    def deliverables(self) -> int:
        """How many finished pieces this run hands over, whatever channel."""
        return len(self.outcomes) + (1 if self.message is not None else 0)


@dataclass
class RunContext:
    """What a step reloads rather than carries between processes.

    Every field here is derivable from the database plus the request, which is
    the property that makes it safe to rebuild: two steps of the same run
    reconstruct the same world because the corpus fingerprint, the stored
    artifacts and the market tables have not moved underneath them.
    """

    artifacts: KnowledgeArtifacts
    corpus: SourceCorpus
    positioning: PositioningMap | None = None
    demand: DemandMap | None = None
    chosen: str = ""
    intelligence: CampaignIntelligence | None = None


class _RunStopped(Exception):
    """A phase decided the run is over, with a finished result to report.

    An exception rather than a sentinel return so `_prepare` has one return
    type and the happy path in `run` stays linear. It is never allowed out of
    this module.
    """

    def __init__(self, result: CampaignRunResult) -> None:
        super().__init__(result.abort_reason or "stopped")
        self.result = result


class EmailCampaignPipeline:
    def __init__(
        self,
        *,
        session: ModelSession,
        knowledge: KnowledgeGateway,
        policy: ExecutionPolicy,
        observer: RunObserver | None = None,
        cancel_token: CancellationToken | None = None,
        deadline: float | None = None,
        material_researcher: MaterialResearcher | None = None,
    ) -> None:
        self._session = session
        self._knowledge = knowledge
        self._policy = policy
        self._observer = observer or RunObserver()
        self._cancel_token = cancel_token
        self._deadline = deadline
        self._material_researcher = material_researcher or MaterialResearcher(session)

    async def run(self, request: CampaignRequest) -> CampaignRunResult:
        result = CampaignRunResult(usage=self._session.usage)
        contract = self.read_contract(request)

        try:
            context = await self._prepare(request, contract, result)
            artifacts, corpus = context.artifacts, context.corpus
            positioning, demand = context.positioning, context.demand
            chosen, intelligence = context.chosen, context.intelligence

            brief = await self._phase_strategy(
                request,
                artifacts,
                corpus,
                contract,
                result,
                positioning,
                demand,
                chosen,
                intelligence,
            )
            if (guard := self._guard()) is not None:
                return self._stopped(request, contract, result, guard)

            if contract.kind is DeliverableKind.LINKEDIN_MESSAGE:
                await self._phase_message(request, brief, artifacts, result)
            else:
                guard = await self._phase_craft(
                    request, brief, artifacts, corpus, result, positioning
                )
                if guard is not None:
                    return self._stopped(request, contract, result, guard)

                recovered = await self._phase_material_recovery(
                    request=request,
                    brief=brief,
                    artifacts=artifacts,
                    corpus=corpus,
                    result=result,
                )
                if recovered is not None:
                    artifacts, corpus, recovery = recovered
                    if (guard := self._guard()) is not None:
                        return self._stopped(request, contract, result, guard)
                    # The first drafts are useful diagnostic work, not the
                    # deliverable.  Re-plan from the enlarged closed world and
                    # craft once more; the recovery phase is deliberately not
                    # called a second time, so a stubborn gap cannot loop.
                    recovered_brief = await self._phase_strategy(
                        request,
                        artifacts,
                        corpus,
                        contract,
                        result,
                        positioning,
                        demand,
                        chosen,
                        intelligence,
                        recovery,
                    )
                    brief = recovered_brief
                    result.outcomes.clear()
                    result.sequence = None
                    if (guard := self._guard()) is not None:
                        return self._stopped(request, contract, result, guard)
                    guard = await self._phase_craft(
                        request, brief, artifacts, corpus, result, positioning
                    )
                    if guard is not None:
                        return self._stopped(request, contract, result, guard)

                if stopped := self._stop_for_unresolved_material(request, contract, result):
                    return stopped
                await self._phase_sequence(request, brief, artifacts, corpus, result)
                if stopped := self._stop_for_unresolved_material(request, contract, result):
                    return stopped
        except _RunStopped as stop:
            # A deliberate stop - cancelled, out of time, or nothing to argue
            # from. Already a finished result; it is not a failure.
            return stop.result
        except ModelRuntimeError as exc:
            # The provider stopped answering, after `ModelSession` had already
            # resent the call. Treated exactly like running out of time: stop
            # between steps, keep everything finished, say why.
            #
            # It reaches here at all because nothing else could catch it. This
            # is not a `CampaignError`, so before this the exception went
            # straight past the pipeline into the orchestrator's crash
            # handler - which persists no assets and no report, and threw
            # away every email the run had already written and paid for.
            logger.warning("pipeline: the provider stopped answering - %s", exc)
            self._observer.on_role_failed(str(exc.details.get("role", "pipeline")), str(exc))
            return self._stopped(request, contract, result, "provider_unavailable")
        except CampaignError as exc:
            logger.warning("pipeline: run failed - %s", exc)
            self._observer.on_role_failed(exc.details.get("role", "pipeline"), str(exc))
            if stopped := self._stop_for_unresolved_material(request, contract, result):
                return stopped
            # A failure that arrives with finished emails behind it is a
            # degraded run, not a failed one. Three good emails out of five
            # are three good emails, and reporting them under a red banner is
            # what teaches a user to distrust the badge on the runs that
            # really did fail.
            result.status = "degraded" if result.delivered else "failed"
            result.abort_reason = str(exc)
            result.report = self._build_report(request, contract, result)
            self._observer.on_report(result.report)
            self._observer.on_phase(
                "stopped", result.abort_reason, {"status": result.status}
            )
            return result

        result.report = self._build_report(request, contract, result)
        result.status = "completed" if result.report.healthy else "degraded"
        self._observer.on_report(result.report)
        below = result.report.below_floor
        if contract.kind is DeliverableKind.LINKEDIN_MESSAGE:
            message = result.message or {}
            self._observer.on_phase(
                "finished",
                f"LinkedIn {message.get('kind', 'message')} ready - "
                f"{message.get('characters', 0)} of {message.get('limit', 0)} characters. "
                "Every claim in it passed the evidence gate; no cold reader grades this "
                "channel, so there is no pull score to report.",
                {"status": result.status, "characters": message.get("characters", 0)},
            )
            return result
        self._observer.on_phase(
            "finished",
            f"{result.report.delivered} email(s) produced - average AI editorial assessment "
            f"{result.report.average_pull:.1f}/10 (uncalibrated)"
            + (
                f" - {len(below)} still under the {PULL_THRESHOLD}/10 floor when the loop "
                "stopped rewriting"
                if below
                else ""
            ),
            {"status": result.status, "below_floor": [line.position for line in below]},
        )
        return result


    # ---------------------------------------------------------- stepped entry

    def read_contract(self, request: CampaignRequest) -> DeliverableContract:
        """How the request was read. Pure, so a later step can recompute it."""
        # The channel decides the deliverable; only an email campaign has a
        # number to read out of the user's sentence.
        contract = linkedin_contract() if request.channel else parse_contract(request.request)
        self._observer.on_phase(
            "contract",
            f"Read the request as {contract.count} {contract.noun}(s)"
            + (" - the user said so" if contract.count_is_explicit else " - not specified"),
            {"count": contract.count, "explicit": contract.count_is_explicit,
             "kind": contract.kind.value},
        )
        return contract

    async def _prepare(
        self, request: CampaignRequest, contract: DeliverableContract, result: CampaignRunResult
    ) -> "RunContext":
        """Everything a run needs before it can plan, and nothing it produces.

        Split out of `run` so a stepped execution can rebuild it in a fresh
        process. It is cheap to repeat: `_phase_knowledge` reuses the stored
        artifacts whenever the corpus fingerprint is unchanged, which costs no
        model call, and the rest is database reads. That is what lets a
        per-email Lambda reload its world instead of carrying it through a
        state machine's 256 KB payload.
        """
        artifacts, corpus = await self._phase_knowledge(result)
        if (guard := self._guard()) is not None:
            raise _RunStopped(self._stopped(request, contract, result, guard))

        intelligence: CampaignIntelligence | None = None
        if bundle := self._knowledge.campaign_intelligence(artifacts):
            artifacts = bundle.artifacts
            intelligence = bundle.context
            result.artifacts = artifacts
            result.intelligence = intelligence.trace
            self._observer.on_phase(
                "intelligence",
                _intelligence_message(intelligence),
                intelligence.trace.model_dump(mode="json"),
            )

        # Said out loud before the strategy is decided rather than
        # discovered on the receipt: what the copy is allowed to argue
        # from constrains the campaign, and no rewrite later on can add a
        # proof the material never contained.
        posture = assess(artifacts)
        self._observer.on_phase(
            "proof",
            posture.summary(),
            {
                "proof": len(posture.proof),
                "checkable": len(posture.checkable),
                "asks": posture.asks[:1],
            },
        )
        if self._policy.require_proof and posture.nothing_to_argue_from:
            raise _RunStopped(self._needs_input(request, contract, result, posture))

        positioning = self._knowledge.positioning()
        if positioning is not None and not positioning.is_empty:
            self._observer.on_phase(
                "market",
                positioning.summary(),
                {
                    "rivals": positioning.rivals_profiled,
                    "open_ground": [
                        str(reading.axis) for reading in positioning.open_ground
                    ],
                },
            )

        demand = self._knowledge.demand()
        chosen = self._knowledge.audience_choice()
        if chosen:
            # Said out loud for the same reason the proof posture is: this
            # decides who every draft in the run is written to and graded
            # by, and a run whose audience was quietly swapped by a form
            # field is a run whose report nobody can read afterwards.
            mapped = demand.named(chosen) if demand is not None else None
            if not any(segment.name == chosen for segment in artifacts.audience.segments):
                selected = mapped.as_segment() if mapped is not None else Segment(name=chosen)
                selected.name = chosen
                artifacts.audience.segments.insert(0, selected)
            self._observer.on_phase(
                "audience",
                f"Written to {chosen}"
                + (
                    " - selected audience hypothesis; response is unmeasured"
                    if mapped is not None
                    else " - which is not on this brand's audience map"
                ),
                {"segment": chosen, "mapped": mapped is not None},
            )
        return RunContext(
            artifacts=artifacts,
            corpus=corpus,
            positioning=positioning,
            demand=demand,
            chosen=chosen,
            intelligence=intelligence,
        )

    @property
    def session_usage(self) -> Usage:
        """The running token tally, so a stepped run can seed a fresh result
        object with the session it is actually spending."""
        return self._session.usage

    async def rebuild_context(
        self, request: CampaignRequest, result: CampaignRunResult
    ) -> "RunContext":
        """The world a step needs, reconstructed in a process that never saw it.

        Safe to call repeatedly and cheap when it matters: the artifacts come
        back from the store whenever the corpus fingerprint is unchanged, which
        is the normal case within one run and costs no model call. Everything
        else is a database read.
        """
        return await self._prepare(request, self.read_contract(request), result)

    async def plan(
        self,
        request: CampaignRequest,
        contract: DeliverableContract,
        result: CampaignRunResult,
    ) -> tuple["RunContext", CampaignBrief]:
        """Step one of a stepped run: know the business, decide the campaign.

        Everything up to and including the single Strategist call, which is
        the one decision the whole sequence has to agree on. Re-planning
        between two emails would produce a second, differently-worded campaign
        and leave emails 3 and 4 arguing something 1 and 2 never agreed to -
        which is why the brief is written down once here and only read
        afterwards.

        `_phase_material_recovery` is deliberately not part of a stepped run.
        It re-plans and re-crafts everything from an enlarged closed world, and
        a step that can restart the whole state machine is not a step. A run
        that needs it should be run in one process.
        """
        context = await self._prepare(request, contract, result)
        brief = await self._phase_strategy(
            request,
            context.artifacts,
            context.corpus,
            contract,
            result,
            context.positioning,
            context.demand,
            context.chosen,
            context.intelligence,
        )
        return context, brief

    async def craft_position(
        self,
        *,
        request: CampaignRequest,
        brief: CampaignBrief,
        context: "RunContext",
        result: CampaignRunResult,
        position: int,
        previous: list[Email],
    ) -> EmailOutcome | None:
        """Step two, run once per email: write the email at `position`.

        `previous` is the emails already accepted, in order, and it is not
        optional context - email N is written knowing what N-1 said. Handing an
        empty list to every position produces five first emails rather than a
        sequence, which is why the accepted copy is persisted between steps.

        Returns None when the guard has tripped, matching `_phase_craft`: stop
        between emails, never inside one, because a half-written email is worse
        than one fewer email.
        """
        if self._guard() is not None:
            return None
        email_brief = next(
            (item for item in brief.emails if item.position == position), None
        )
        if email_brief is None:
            return None
        self._observer.on_phase(
            "craft",
            f"Email {email_brief.position} of {len(brief.emails)}: "
            f"{email_brief.single_idea or email_brief.job}",
            {"position": email_brief.position},
        )
        loop = self._craft_loop(
            context.artifacts, context.corpus, brief, context.positioning
        )
        outcome = await loop.craft(
            brief=email_brief, campaign=brief, request=request, previous=previous
        )
        if outcome.unresolved_failure_mode == "missing_material":
            raise CraftError(
                f"Email {position} still needs verified material: {outcome.unresolved_strategy}",
                role="conversion_critic",
                position=position,
            )
        return outcome

    async def conclude(
        self,
        *,
        request: CampaignRequest,
        contract: DeliverableContract,
        brief: CampaignBrief,
        context: "RunContext",
        result: CampaignRunResult,
    ) -> CampaignRunResult:
        """Step three: read the emails as one sequence, then report.

        `result.outcomes` must already hold every email the run produced -
        the sequence pass reads them together, which is the whole point of it,
        and reworks the ones the others break.
        """
        await self._phase_sequence(request, brief, context.artifacts, context.corpus, result)
        result.report = self._build_report(request, contract, result)
        if result.status not in ("cancelled", "needs_input"):
            result.status = "completed" if result.report.healthy else "degraded"
        self._observer.on_report(result.report)
        return result

    # ----------------------------------------------------------- phase zero

    async def _phase_knowledge(
        self, result: CampaignRunResult
    ) -> tuple[KnowledgeArtifacts, SourceCorpus]:
        corpus = self._knowledge.corpus()
        fingerprint = self._knowledge.fingerprint()
        stored = self._knowledge.load()

        if (
            stored is not None
            and stored.fingerprint == fingerprint
            and not self._policy.force_recompile
        ):
            # Nothing the user gave us has changed since this was compiled.
            # Re-reading their whole site to reach the same conclusions is the
            # most expensive way to learn nothing.
            self._observer.on_phase(
                "knowledge",
                f"Reusing what we already know about this business "
                f"(version {stored.version}, {len(stored.artifacts.evidence.entries)} facts)",
                {"reused": True, "version": stored.version},
            )
            self._observer.on_knowledge(stored.artifacts, True, stored.version)
            result.artifacts = stored.artifacts
            return stored.artifacts, corpus

        # An empty corpus costs no model call at all, so it gets no step of its
        # own - a zero-token "Knowledge Compiler" row in the timeline would be
        # work the run never did.
        reading = not corpus.is_empty
        if reading:
            self._observer.on_role_started(
                COMPILER_ROLE,
                f"Reading {len(corpus.documents)} document(s)",
                {"documents": len(corpus.documents)},
            )
        else:
            self._observer.on_phase(
                "knowledge",
                "The user provided no material to read - the copy will have nothing "
                "specific to say",
                {"documents": 0},
            )
        artifacts = await KnowledgeCompiler(self._session).compile(
            corpus,
            on_progress=lambda stage, message: self._observer.on_phase(
                "knowledge", message, {"stage": stage}
            ),
        )
        saved = self._knowledge.save(artifacts, fingerprint)
        if reading:
            self._observer.on_role_finished(
                COMPILER_ROLE,
                f"{len(artifacts.evidence.entries)} facts, {len(artifacts.audience.segments)} "
                f"segment(s), {len(artifacts.gaps.unanswered)} gap(s)",
                {"version": saved.version, "evidence": len(artifacts.evidence.entries)},
            )
        self._observer.on_knowledge(saved.artifacts, False, saved.version)
        result.artifacts = saved.artifacts
        return saved.artifacts, corpus

    # ------------------------------------------------------------ phase one

    async def _phase_strategy(
        self,
        request: CampaignRequest,
        artifacts: KnowledgeArtifacts,
        corpus: SourceCorpus,
        contract: DeliverableContract,
        result: CampaignRunResult,
        positioning: PositioningMap | None = None,
        demand: DemandMap | None = None,
        chosen_segment: str = "",
        intelligence: CampaignIntelligence | None = None,
        recovery: MaterialRecovery | None = None,
    ) -> CampaignBrief:
        self._observer.on_role_started(
            STRATEGIST_ROLE, "Deciding what this campaign says, and in what order"
        )
        brief = await Strategist(self._session).build(
            request=request,
            artifacts=artifacts,
            corpus=corpus,
            contract=contract,
            prior_learnings=self._knowledge.prior_learnings(),
            positioning=positioning,
            demand=demand,
            chosen_segment=chosen_segment,
            intelligence=intelligence,
            recovery=recovery,
        )
        result.brief = brief
        if intelligence is not None:
            attach_selected_dossier_objection(
                artifacts,
                intelligence,
                [item.objection for item in brief.emails if item.objection],
            )
        self._observer.on_brief(brief)
        if intelligence is not None:
            self._observer.on_phase(
                "intelligence",
                "Campaign intelligence applied to the normalized brief",
                intelligence.trace.model_dump(mode="json"),
            )
        self._observer.on_role_finished(
            STRATEGIST_ROLE,
            f"{len(brief.emails)} email(s) to {brief.reader or 'the target reader'}",
            {"emails": [item.summary() for item in brief.emails]},
        )

        # Announced rather than left implicit: who grades the copy decides
        # what every rewrite in the run is aiming at, and it is the one
        # decision here that used to be made by list order.
        segment = artifacts.audience.match(brief.reader_segment, brief.reader)
        fallback = artifacts.audience.primary()
        self._observer.on_phase(
            "strategy",
            "Drafts will be read cold by: "
            + (
                brief.reader_profile_override
                if brief.reader_profile_override
                else segment.name
                if segment is not None
                else f"{fallback.name} (the brief named no segment we know)"
                if fallback is not None
                else "a busy professional - the material named no audience at all"
            ),
            {
                "segment": brief.reader_profile_override or (segment.name if segment is not None else ""),
                "matched": not brief.reader_profile_override and segment is not None,
                "audience_source": "user" if brief.reader_profile_override else "compiled",
            },
        )
        return brief

    # ------------------------------------------------------------ phase two

    async def _phase_craft(
        self,
        request: CampaignRequest,
        brief: CampaignBrief,
        artifacts: KnowledgeArtifacts,
        corpus: SourceCorpus,
        result: CampaignRunResult,
        positioning: PositioningMap | None = None,
    ) -> str | None:
        loop = self._craft_loop(artifacts, corpus, brief, positioning)
        accepted: list[Email] = []

        for email_brief in brief.emails:
            if (guard := self._guard()) is not None:
                # Stop between emails, never inside one: a half-written email
                # is worse than one fewer email.
                return guard
            self._observer.on_phase(
                "craft",
                f"Email {email_brief.position} of {len(brief.emails)}: "
                f"{email_brief.single_idea or email_brief.job}",
                {"position": email_brief.position},
            )
            outcome = await loop.craft(
                brief=email_brief, campaign=brief, request=request, previous=accepted
            )
            if outcome.best.gates.blocking:
                details = "; ".join(issue.detail for issue in outcome.best.gates.blocking)
                raise CraftError(
                    f"Email {email_brief.position} failed automatic checks after repair: {details}",
                    role="email_writer",
                    position=email_brief.position,
                )
            result.outcomes.append(outcome)
            accepted.append(outcome.email)
        return None

    async def _phase_material_recovery(
        self,
        *,
        request: CampaignRequest,
        brief: CampaignBrief,
        artifacts: KnowledgeArtifacts,
        corpus: SourceCorpus,
        result: CampaignRunResult,
    ) -> tuple[KnowledgeArtifacts, SourceCorpus, MaterialRecovery] | None:
        """Replan from cited proof or resolve missing material, at most once."""

        gaps: list[str] = []
        argument_gaps: list[str] = []
        for outcome in result.outcomes:
            if not outcome.unresolved_strategy:
                continue
            missing = next(
                (
                    version.critique
                    for version in reversed(outcome.versions)
                    if version.critique is not None
                    and version.critique.failure_mode == "missing_material"
                ),
                None,
            )
            if missing is not None:
                gaps.append(missing.strategy_gap or outcome.unresolved_strategy)
                continue
            argument = next(
                (
                    version.critique
                    for version in reversed(outcome.versions)
                    if version.critique is not None
                    and version.critique.failure_mode == "argument"
                ),
                None,
            )
            if argument is not None:
                argument_gaps.append(argument.strategy_gap or outcome.unresolved_strategy)
        gaps = list(dict.fromkeys(gap.strip() for gap in gaps if gap.strip()))
        if not gaps:
            argument_gaps = list(dict.fromkeys(
                gap.strip() for gap in argument_gaps if gap.strip()
            ))
            if not argument_gaps:
                return None
            gap = "\n".join(f"- {item}" for item in argument_gaps)
            recovery = cited_recovery(gap=gap, artifacts=artifacts)
            if recovery is None:
                recovery = existing_recovery(gap=gap, artifacts=artifacts)
            if recovery is None:
                return None
            self._observer.on_phase(
                "material_recovery",
                "The critic cited existing verified proof; rebuilding the argument once",
                {
                    "gaps": argument_gaps,
                    "recovered": True,
                    "reused": True,
                    "evidence_ids": [entry.id for entry in recovery.evidence],
                },
            )
            enriched, enlarged_corpus = apply_recovery(artifacts, corpus, recovery)
            result.artifacts = enriched
            return enriched, enlarged_corpus, recovery

        gap = "\n".join(f"- {item}" for item in gaps)
        if recovery := existing_recovery(gap=gap, artifacts=artifacts):
            self._observer.on_phase(
                "material_recovery",
                (
                    f"Reusing {len(recovery.evidence)} verified fact(s) already found by an "
                    "earlier automatic recovery; rebuilding the strategy once"
                ),
                {
                    "gaps": gaps,
                    "recovered": True,
                    "reused": True,
                    "evidence_ids": [entry.id for entry in recovery.evidence],
                    "sources": [entry.source for entry in recovery.evidence],
                },
            )
            enriched, enlarged_corpus = apply_recovery(artifacts, corpus, recovery)
            result.artifacts = enriched
            return enriched, enlarged_corpus, recovery

        self._observer.on_phase(
            "material_recovery",
            "The copy exposed missing campaign material; searching official sources now",
            {"gaps": gaps, "attempt": 1, "maximum_attempts": 1},
        )
        self._observer.on_role_started(
            MATERIAL_RESEARCH_ROLE,
            f"Finding and verifying official material for {len(gaps)} gap(s)",
        )
        try:
            recovery = await self._material_researcher.recover(
                gap=gap,
                artifacts=artifacts,
                reader=brief.reader,
                request=request.request,
            )
        except ModelRuntimeError as exc:
            # Research is a recovery path.  If search is unavailable, preserve
            # the honest original result rather than turning a usable degraded
            # campaign into a provider failure.
            self._observer.on_role_failed(MATERIAL_RESEARCH_ROLE, str(exc))
            self._observer.on_phase(
                "material_recovery",
                "Official-source recovery was unavailable; the original gap remains explicit",
                {"gaps": gaps, "recovered": False},
            )
            return None

        self._observer.on_role_finished(
            MATERIAL_RESEARCH_ROLE,
            (
                f"Verified {len(recovery.evidence)} fact(s) from "
                f"{len(recovery.sources)} official source(s)"
                if recovery.recovered
                else recovery.note or "No verified official fact closed the gap"
            ),
            {
                "recovered": recovery.recovered,
                "evidence": [entry.model_dump(mode="json") for entry in recovery.evidence],
                "sources": [source.final_url for source in recovery.sources],
                "dropped_claims": recovery.dropped_claims,
            },
        )
        if not recovery.recovered:
            self._observer.on_phase(
                "material_recovery",
                "No official source verified the missing fact; rebuilding a narrower strategy once",
                {"gaps": gaps, "recovered": False},
            )
            return artifacts, corpus, recovery

        enriched, enlarged_corpus = apply_recovery(artifacts, corpus, recovery)
        stored = self._knowledge.commit_recovered_material(recovery, enriched)
        if stored is not None:
            enriched = stored.artifacts
            enlarged_corpus = self._knowledge.corpus()
        result.artifacts = enriched
        self._observer.on_phase(
            "material_recovery",
            f"Recovered {len(recovery.evidence)} verified fact(s) "
            f"({len(enriched.evidence.entries) - len(artifacts.evidence.entries)} new); "
            "rebuilding the strategy once",
            {
                "gaps": gaps,
                "recovered": True,
                "evidence_ids": [entry.id for entry in recovery.evidence],
                "sources": [source.final_url for source in recovery.sources],
            },
        )
        return enriched, enlarged_corpus, recovery

    async def _phase_message(
        self,
        request: CampaignRequest,
        brief: CampaignBrief,
        artifacts: KnowledgeArtifacts,
        result: CampaignRunResult,
    ) -> None:
        """The craft phase for a LinkedIn campaign: one draft, the same
        evidence gate every email passes, and one rewrite against its own
        failures.

        Deliberately not the email loop. That loop's value is the cold reader,
        the duel and the critic, all of which grade a piece of copy a stranger
        reads in an inbox - a panel that has never seen a LinkedIn message
        would be scoring the wrong artefact, and a pull number from it would
        be a measurement of nothing. What survives the change of channel is
        what is deterministic: no unlicensed number, price, quotation or URL.
        """
        channel = request.channel
        assert channel is not None  # the contract is only LinkedIn when it is set
        message_brief = brief.emails[0] if brief.emails else None
        self._observer.on_phase(
            "craft",
            f"Writing one LinkedIn {channel.kind} to {channel.recipient_name}: "
            + (message_brief.single_idea if message_brief else "no brief came back"),
            {"recipient": channel.recipient_name, "kind": channel.kind},
        )
        self._observer.on_role_started(
            LINKEDIN_WRITER_ROLE, f"Writing to {channel.recipient_name}"
        )
        # The objective is the campaign's goal when the user set one - it is
        # the sentence that says what a reply is for - and the request itself
        # otherwise, which is the only other thing they wrote.
        objective = (request.goals or "").strip() or request.request
        try:
            result.message = await write_message(
                self._session,
                channel.message_request(objective),
                artifacts,
                brief=message_brief,
                campaign=brief,
            )
        except OutputValidationError as exc:
            # A draft that still fails its own checks after being handed them
            # is a craft failure, not a provider one: the model answered, and
            # what it answered cannot ship.
            raise CraftError(str(exc), role=LINKEDIN_WRITER_ROLE) from exc
        self._observer.on_role_finished(
            LINKEDIN_WRITER_ROLE,
            f"{result.message['characters']} of {result.message['limit']} characters",
            {"characters": result.message["characters"], "limit": result.message["limit"]},
        )

    # ---------------------------------------------------------- phase three

    async def _phase_sequence(
        self,
        request: CampaignRequest,
        brief: CampaignBrief,
        artifacts: KnowledgeArtifacts,
        corpus: SourceCorpus,
        result: CampaignRunResult,
    ) -> None:
        if len(result.outcomes) < 2 or self._policy.max_sequence_reworks == 0:
            return
        if self._guard() is not None:
            return

        self._observer.on_role_started(
            SEQUENCE_ROLE, f"Reading all {len(result.outcomes)} emails as one sequence"
        )
        report = await SequenceReviewer(self._session).review(
            result.emails, brief, arc_read=self._policy.sequence_pass, request=request
        )
        result.sequence = report
        self._observer.on_sequence(report)
        self._observer.on_role_finished(
            SEQUENCE_ROLE,
            "The sequence holds together"
            if report.passed
            else f"{len(report.rework)} email(s) need reworking",
            {"passed": report.passed},
        )
        if report.passed:
            return

        loop = self._craft_loop(artifacts, corpus, brief)
        reworked = 0
        for position in sorted(report.rework):
            if reworked >= self._policy.max_sequence_reworks or self._guard() is not None:
                break
            outcome = next(
                (item for item in result.outcomes if item.brief.position == position), None
            )
            if outcome is None:
                continue
            self._observer.on_phase(
                "sequence",
                f"Reworking email {position}: {'; '.join(report.rework[position])}",
                {"position": position},
            )
            others = [item.email for item in result.outcomes if item.brief.position != position]
            await loop.rework(
                outcome=outcome,
                campaign=brief,
                request=request,
                previous=others,
                instruction=(
                    "Read as part of the whole sequence, this email has a problem the other "
                    f"emails create:\n{report.instruction_for(position)}"
                ),
            )
            reworked += 1

    # ------------------------------------------------------------- internals

    def _craft_loop(
        self,
        artifacts: KnowledgeArtifacts,
        corpus: SourceCorpus,
        brief: CampaignBrief,
        positioning: PositioningMap | None = None,
    ) -> CraftLoop:
        return CraftLoop(
            writer=EmailWriter(self._session, self._observer),
            reader=BlindReader(self._session),
            critic=ConversionCritic(self._session) if self._policy.critic_enabled else None,
            judge=PreferenceJudge(self._session) if self._policy.tournament else None,
            subjects=(
                SubjectBakeOff(self._session) if self._policy.subject_variants else None
            ),
            subject_variants=self._policy.subject_variants,
            artifacts=artifacts,
            evidence=EvidenceIndex(artifacts.evidence, corpus.text),
            corpus=corpus,
            personas=personas_for(
                artifacts.audience,
                artifacts.audience.match(brief.reader_segment, brief.reader),
                panel=self._policy.reader_panel,
                explicit_audience=brief.reader_profile_override,
                reader_scope=getattr(brief, "reader_scope", ""),
            ),
            merge_fields=self._policy.merge_fields,
            max_revisions=self._policy.max_revisions,
            candidates=self._policy.draft_candidates,
            positioning=positioning,
            observer=self._observer,
            cancel_token=self._cancel_token,
        )

    def _guard(self) -> str | None:
        if self._cancel_token is not None and self._cancel_token.is_cancelled:
            return "cancelled"
        if self._deadline is not None and time.monotonic() >= self._deadline:
            return "timed_out"
        budget = self._policy.max_total_tokens
        if budget is not None and self._session.usage.total_tokens >= budget:
            return "budget_exhausted"
        return None

    @staticmethod
    def _withhold_unresolved_material(result: CampaignRunResult) -> list[EmailOutcome]:
        blocked = [
            outcome for outcome in result.outcomes
            if outcome.unresolved_failure_mode == "missing_material"
            and outcome.unresolved_strategy
        ]
        blocked_ids = {id(outcome) for outcome in blocked}
        result.outcomes = [
            outcome for outcome in result.outcomes if id(outcome) not in blocked_ids
        ]
        return blocked

    def _stop_for_unresolved_material(
        self,
        request: CampaignRequest,
        contract: DeliverableContract,
        result: CampaignRunResult,
    ) -> CampaignRunResult | None:
        """Keep verified emails, but do not deliver a typed missing-material gap."""
        blocked = self._withhold_unresolved_material(result)
        if not blocked:
            return None
        result.status = "degraded" if result.outcomes else "needs_input"
        result.abort_reason = "; ".join(
            f"Email {outcome.brief.position} still needs verified material: "
            f"{outcome.unresolved_strategy}"
            for outcome in blocked
        )
        result.report = self._build_report(request, contract, result)
        material_questions = list(dict.fromkeys(
            f"Provide verified material to resolve: {outcome.unresolved_strategy}"
            for outcome in blocked
        ))
        result.report.questions = material_questions
        result.report.what_would_help_most = material_questions[0]
        self._observer.on_report(result.report)
        self._observer.on_phase(
            "stopped", result.abort_reason, {"status": result.status}
        )
        return result

    def _stopped(
        self,
        request: CampaignRequest,
        contract: DeliverableContract,
        result: CampaignRunResult,
        guard: str,
    ) -> CampaignRunResult:
        """A run that ran out of time, budget or patience still hands over
        whatever is finished. Degrading to "here are three of the five, and
        here is why" beats failing a campaign that has minutes of good work
        in it."""
        blocked = self._withhold_unresolved_material(result)
        result.status = guard  # type: ignore[assignment]
        result.abort_reason = _GUARD_MESSAGES.get(guard, guard)
        result.report = self._build_report(request, contract, result)
        if blocked:
            result.report.questions = list(dict.fromkeys(
                f"Provide verified material to resolve: {outcome.unresolved_strategy}"
                for outcome in blocked
            ))
            result.report.what_would_help_most = result.report.questions[0]
            result.report.notes.append(
                "Withheld emails needing verified material: "
                + ", ".join(str(outcome.brief.position) for outcome in blocked)
            )
        self._observer.on_report(result.report)
        self._observer.on_phase("stopped", result.abort_reason, {"status": guard})
        return result

    def _needs_input(
        self,
        request: CampaignRequest,
        contract: DeliverableContract,
        result: CampaignRunResult,
        posture: "ProofPosture",
    ) -> CampaignRunResult:
        """Stop before the strategy, and say what would unblock it.

        This is the one refusal in the pipeline, and it exists because the
        alternative is not a worse campaign - it is the same campaign, written,
        disbelieved by a cold reader, rewritten and disbelieved again. No
        rewrite has ever added a proof the material did not contain, so a run
        with nothing to argue from spends its whole budget discovering
        something `preflight.assess` establishes for free before the first
        model call.

        Narrow on purpose. It fires only when there is neither third-party
        proof *nor* anything a reader could check for themselves - the case
        where every sentence would be this company asserting something about
        itself - or when the compiler found a hole a campaign cannot be written
        around at all, like no action to ask for. A business with no
        testimonials but a real price, a real limit and a real mechanism is not
        blocked: specific beats persuasive, and that campaign is worth writing.
        """
        result.status = "needs_input"
        result.abort_reason = (
            "Nothing here can carry a campaign yet: "
            + posture.summary().lower()
            + ". Answering the questions below is worth more than any rewrite."
        )
        result.report = self._build_report(request, contract, result)
        result.report.questions = list(posture.asks)
        self._observer.on_report(result.report)
        self._observer.on_phase(
            "stopped",
            result.abort_reason,
            {"status": "needs_input", "questions": posture.asks},
        )
        return result

    def _message_report(
        self,
        request: CampaignRequest,
        contract: DeliverableContract,
        result: CampaignRunResult,
    ) -> CampaignReport:
        """One line, and no scores that were never measured.

        `read_reported=False` is the same flag an email carries when its cold
        read never came back, and it means the same thing here: the pull
        column is a placeholder, not a zero. `reads_expected=False` is what
        stops the run being marked degraded for a panel this channel does not
        have.
        """
        lines: list[EmailReportLine] = []
        brief = result.brief.emails[0] if result.brief and result.brief.emails else None
        if result.message is not None and result.artifacts is not None:
            assigned = [
                entry
                for id_ in (brief.evidence_ids if brief else [])
                if (entry := result.artifacts.evidence.get(id_)) is not None
            ]
            spent = assess_text(
                result.message["body"], assigned, result.artifacts.evidence.entries
            )
            lines.append(
                EmailReportLine(
                    position=1,
                    subject=f"LinkedIn {result.message['kind']} to "
                    f"{result.message['recipient_name']}",
                    single_idea=brief.single_idea if brief else "",
                    # It shipped, so every gate passed: an unlicensed number or
                    # quotation sends the draft back and a second failure means
                    # there is no message to report on at all.
                    clean=True,
                    read_reported=False,
                    evidence_assigned=brief.evidence_ids if brief else [],
                    evidence_spent=list(spent.carried),
                    attributions=spent.attributions,
                )
            )
        violations = check_contract(contract, len(lines))
        gaps = result.artifacts.gaps.unanswered if result.artifacts else []
        posture = assess(result.artifacts) if result.artifacts else None
        return CampaignReport(
            request=request.request,
            delivered=len(lines),
            promised=contract.count,
            reads_expected=False,
            effective_audience=self._effective_audience(result),
            audience_scope=getattr(result.brief, "reader_scope", ""),
            contract_violations=[violation.detail for violation in violations],
            emails=lines,
            limiting_gaps=[f"{gap.missing} - {gap.impact}" for gap in gaps],
            what_would_help_most=posture.asks[0] if posture and posture.asks else "",
            knowledge_version=result.artifacts.version if result.artifacts else 0,
            notes=([result.abort_reason] if result.abort_reason else []) + self._audience_notes(result),
        )

    def _build_report(
        self,
        request: CampaignRequest,
        contract: DeliverableContract,
        result: CampaignRunResult,
    ) -> CampaignReport:
        if contract.kind is DeliverableKind.LINKEDIN_MESSAGE:
            return self._message_report(request, contract, result)
        lines = [
            EmailReportLine(
                position=outcome.brief.position,
                subject=outcome.email.subject,
                single_idea=outcome.selected_brief.single_idea,
                pull=outcome.best.read.pull,
                revisions=len(outcome.versions) - 1,
                clean=not outcome.best.gates.blocking,
                landed=outcome.best.read.landed and not outcome.unresolved_strategy,
                rewrites_stopped_helping=outcome.stopped_early,
                read_reported=outcome.best.read.has_verdict,
                understood=outcome.best.read.understood,
                relevant=outcome.best.read.relevant,
                evidence_assigned=outcome.selected_brief.evidence_ids,
                evidence_spent=list(outcome.best.substantiation.carried),
                attributions=outcome.best.substantiation.attributions,
                unresolved=[issue.detail for issue in outcome.best.gates.blocking]
                + (["Unresolved strategy/material gap: " + outcome.unresolved_strategy] if outcome.unresolved_strategy else [])
                + (["Unresolved audience mismatch: " + "; ".join(r.relevance_feedback for r in outcome.best.read.reported if r.situation_matches is False)] if not outcome.best.read.relevant else []),
                reader_verdicts=ReaderVerdict.from_panel(outcome.best.read),
                sameness=[
                    issue.detail
                    for issue in outcome.best.gates.issues
                    if issue.gate == "sameness"
                ],
            )
            for outcome in result.outcomes
        ]
        violations = check_contract(contract, len(result.outcomes))
        gaps = result.artifacts.gaps.unanswered if result.artifacts else []
        posture = assess(result.artifacts) if result.artifacts else None
        return CampaignReport(
            request=request.request,
            delivered=len(result.outcomes),
            promised=contract.count,
            effective_audience=self._effective_audience(result),
            audience_scope=getattr(result.brief, "reader_scope", ""),
            contract_violations=[violation.detail for violation in violations],
            emails=lines,
            limiting_gaps=[f"{gap.missing} - {gap.impact}" for gap in gaps],
            what_would_help_most=_reader_recommendation(lines) or (posture.asks[0] if posture and posture.asks else ""),
            sequence_summary=result.sequence.verdict.summary if result.sequence else "",
            knowledge_version=result.artifacts.version if result.artifacts else 0,
            notes=(
                ([result.abort_reason] if result.abort_reason else [])
                + self._audience_notes(result)
                + (["Audience context: " + result.intelligence.audience_resolution_status
                    + ("; legacy fallback used" if result.intelligence.legacy_fallback_used else "")]
                   + result.intelligence.validation_warnings if result.intelligence else [])
                + self._economy_note(lines)
            ),
        )

    @staticmethod
    def _effective_audience(result: CampaignRunResult) -> str:
        if result.brief is None:
            return ""
        if result.brief.reader_profile_override.strip():
            return result.brief.reader_profile_override.strip()
        audience = result.artifacts.audience if result.artifacts else None
        selected = audience.match(result.brief.reader_segment, result.brief.reader) if audience else None
        selected = selected or (audience.primary() if audience else None)
        return selected.name if selected else "Audience unspecified; no recipient situation was established"

    def _audience_notes(self, result: CampaignRunResult) -> list[str]:
        effective = self._effective_audience(result)
        if not effective:
            return []
        scope = getattr(result.brief, "reader_scope", "")
        return ["Effective audience: " + effective + (". Qualified scope: " + scope if scope else "")]

    def _economy_note(self, lines: list[EmailReportLine]) -> list[str]:
        """Describe review depth without attributing a weak result to spend.

        A simulated reader asking for unavailable product evidence cannot be
        satisfied by a larger panel or another rewrite. Establish the cause
        before recommending more paid work.
        """
        below = [line for line in lines if line.read_reported and not line.landed]
        if not below:
            return []
        starved = [
            name
            for name, on in (
                ("more than one opening per email", self._policy.draft_candidates > 1),
                ("a panel of cold readers rather than one", self._policy.reader_panel),
                ("the conversion critic", self._policy.critic_enabled),
                ("alternative subject lines", self._policy.subject_variants > 0),
                ("more than one rewrite", self._policy.max_revisions > 1),
            )
            if not on
        ]
        if len(starved) < 3:
            return []
        return [
            f"{len(below)} email(s) came in under the floor on a run configured without "
            + ", ".join(starved)
            + ". These settings describe review depth, not the cause of the weak result. "
            "Check the audience fit and verified support for the reported obstacle first; "
            "additional readers or rewrites cannot supply missing evidence."
        ]


def _reader_recommendation(lines: list[EmailReportLine]) -> str:
    """Prioritize observed CTA friction; never promote a reader wish to a fact."""
    verdicts = [v for line in lines for v in line.reader_verdicts]
    mismatches = [v for v in verdicts if v.situation_matches is False]
    if mismatches:
        return "Recheck the selected audience situation: " + mismatches[0].relevance_feedback
    blockers = [v.to_click_it_would_have_to or v.biggest_doubt for v in verdicts if v.biggest_doubt or v.to_click_it_would_have_to]
    if not blockers:
        return ""
    priority = max(dict.fromkeys(blockers), key=blockers.count)
    return ("Resolve this simulated next-step obstacle: " + priority
            + " Check existing verified material first; surface a supported answer or documentation link appropriate to the CTA. If absent, obtain this specific information. Reader expectations are not product evidence.")
