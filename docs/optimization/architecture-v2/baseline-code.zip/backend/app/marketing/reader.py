"""The Blind Reader: the one role in the system defined by what it is not given.

It never sees the request, the brief, the positioning, the product docs or the
intent. That is not an oversight to be fixed - it is the entire mechanism. Ask
a model that has read the brief "what is this email selling you?" and it
answers from the brief; the gaps in the copy get filled in from context that
no real recipient will ever have. Ask a model that has only the email, and the
answer means something.

This is also the template for when a role deserves to exist at all in this
architecture. Not "a marketing team has a proofreader" - an org chart is not
an information-flow argument. A role earns its own context when its ignorance
or its independence is load-bearing. This one's is.

Carried over almost unchanged from the old email agent, where it was the best
idea in the codebase and was buried as a private method of one specialist.
"""

import asyncio
import logging
import statistics

from pydantic import BaseModel, Field, model_validator

from app.ai.model_router import ModelTier
from app.knowledge.artifacts import AudienceModel, Segment
from app.marketing.email_copy import Email, render_review
from app.runtime.exceptions import ModelRuntimeError
from app.runtime.model_session import ModelSession

logger = logging.getLogger("marketingos.marketing")

ROLE_ID = "blind_reader"

#: Editorial adequacy threshold for a simulated reader, never a send prediction.
PULL_THRESHOLD = 7

#: Historical serialization compatibility only. New reader calls do not ask
#: for frequencies and never use this scale to produce an assessment.
_PULL_BY_CLICKS: tuple[tuple[int, int], ...] = (
    (25, 10),
    (14, 9),
    (9, 8),
    (6, 7),
    (4, 6),
    (3, 5),
    (2, 4),
    (1, 2),
)


def pull_from_clicks(clicks_in_100: int) -> int:
    """Read the historical score scale without reinterpreting old snapshots."""
    return next((score for floor, score in _PULL_BY_CLICKS if clicks_in_100 >= floor), 0)


class ReaderAssessment(BaseModel):
    """Current model response: editorial feedback with no invented frequencies."""

    opened: bool = False
    stopped_at: str = ""
    what_it_sells: str = ""
    #: Whether they could actually say what is being sold, without guessing.
    #:
    #: `what_it_sells` has been collected since this role existed and was
    #: never anything but prose: a reader could answer "honestly, no idea -
    #: some kind of consulting?" and the draft still competed on its click
    #: estimate alone, because that sentence reached no comparison, no gate
    #: and no rewrite rule. This is the same answer as a fact the loop can
    #: act on, and it is the one the whole system was missing - a stranger
    #: who cannot say what the thing is has not been sold anything, however
    #: well the email reads.
    #:
    #: True by default so a read built by hand - a test, a replayed history -
    #: is not silently counted as a confused one. Only a reader who was asked
    #: can say no.
    understood: bool = True
    situation_matches: bool | None = None
    relevance_feedback: str = ""
    assumed_experiences: list[str] = Field(default_factory=list)
    problem_now: str = ""
    biggest_doubt: str = ""
    would_act: bool = False
    #: What the email would have had to say for this reader to click. The one
    #: generative question in the system: everything else the loop collects is
    #: a verdict on what was written, and this is the only field that says what
    #: to write instead - in the reader's own words rather than a critic's.
    to_click_it_would_have_to: str = ""
    #: Uncalibrated editorial assessment. No probability or performance unit.
    pull: int = Field(default=0, ge=0, le=10)
    fixes: list[str] = Field(default_factory=list)
    #: Which reader this was, when a panel read the same draft.
    persona: str = ""
    #: False when this reader never came back with anything - a malformed
    #: response, not a verdict. Kept as a flag rather than encoded as a score,
    #: because every score is a claim about the copy and this one would be a
    #: lie in whichever direction it was rounded.
    reported: bool = True


class BlindRead(ReaderAssessment):
    """A persisted assessment, also able to read historical frequency fields."""

    opens_in_100: int | None = Field(default=None, ge=0, le=100)
    clicks_in_100: int | None = Field(default=None, ge=0, le=100)

    @model_validator(mode="after")
    def _derive_pull(self) -> "BlindRead":
        """Preserve the old interpretation only when loading historical fields."""
        if self.clicks_in_100 is None:
            return self
        if self.opens_in_100 is not None and self.clicks_in_100 > self.opens_in_100:
            self.clicks_in_100 = self.opens_in_100
        self.pull = pull_from_clicks(self.clicks_in_100)
        return self

    @property
    def landed(self) -> bool:
        """Whether this simulated reading clears the editorial threshold.

        Comprehension first, and as a veto rather than as a term. A click
        estimate on an email the reader could not parse is not a low score -
        it is a number about a different question, and letting it clear the
        floor ships copy whose own reader could not say what it was for.
        """
        return self.reported and self.understood and self.situation_matches is not False and self.pull >= PULL_THRESHOLD

    def render(self) -> str:
        lines = [
            f"- Would they have opened it? {'yes' if self.opened else 'no'}",
            (
                f"- What they think it sells: {self.what_it_sells or 'they could not say'}"
                if self.understood
                else "- COULD NOT SAY WHAT THIS IS. Their best guess: "
                + (self.what_it_sells or "nothing at all")
            ),
            f"- Where they stopped reading: {self.stopped_at or 'they read to the end'}",
            f"- What would stop them clicking: {self.biggest_doubt or 'nothing they named'}",
        ]
        lines.append(f"- AI simulation assessment (uncalibrated): {self.pull}/10")
        if self.situation_matches is False:
            lines.append("- SUBSTANTIAL AUDIENCE MISMATCH: " + self.relevance_feedback)
        elif self.relevance_feedback:
            lines.append("- Situation recognition: " + self.relevance_feedback)
        if self.assumed_experiences:
            lines.append("- Assumed experiences/installations: " + "; ".join(self.assumed_experiences))
        if self.problem_now:
            lines.append("- Importance now: " + self.problem_now)
        if self.to_click_it_would_have_to:
            lines.append(
                f"- What it would have had to say for them to click: "
                f"{self.to_click_it_would_have_to}"
            )
        if self.fixes:
            lines.append("- Lines they would cut or change: " + "; ".join(self.fixes))
        return "\n".join(lines)


class PanelRead(BaseModel):
    """Several cold readers on the same draft.

    Variance is the signal a single read cannot give: copy that one person
    loves and another cannot parse is not finished, and a single score would
    hide that. Every reader's report goes back to the writer in full - see
    `render` - so the rewrite answers the hardest one, not the average one.
    """

    reads: list[BlindRead] = Field(default_factory=list)

    @property
    def reported(self) -> list[BlindRead]:
        return [read for read in self.reads if read.reported]

    @property
    def has_verdict(self) -> bool:
        """Whether anybody actually read this. A draft nobody could report on
        is not a draft that scored zero, and the difference decides whether
        the number downstream means anything."""
        return bool(self.reported)

    @property
    def pull(self) -> float:
        """The panel's one number: the middle reader, not the average one.

        A mean hands one reader who scores everything low a permanent veto
        over the campaign's headline number - and, through
        `EmailVersion.score`, over which rewrite is kept. The median answers
        the question that decides whether copy ships, which is what the middle
        reader felt, and one outlier in either direction cannot move it. With
        a single reader the two are the same number.
        """
        return statistics.median(read.pull for read in self.reported) if self.reported else 0.0

    @property
    def clicks_in_100(self) -> float:
        """Historical payload compatibility; new reads never supply this value."""
        estimates = [
            read.clicks_in_100 for read in self.reported if read.clicks_in_100 is not None
        ]
        return statistics.median(estimates) if estimates else 0.0

    @property
    def understood(self) -> bool:
        """Whether the panel could say what the email was selling.

        Majority, like `landed`, and for the same reason: one reader in three
        who missed it is what copy that works looks like, and two is a draft
        with a real problem. An unread panel is not a confused one - it has
        no verdict on this either, so it answers yes and the other checks
        decide.
        """
        got = sum(1 for read in self.reported if read.understood)
        return not self.reported or got * 2 > len(self.reported)

    @property
    def relevant(self) -> bool:
        """A substantive mismatch from any reported scenario requires attention."""
        return not any(read.situation_matches is False for read in self.reported)

    @property
    def confused(self) -> list[BlindRead]:
        """The readers who could not say what it was, and what they guessed
        instead. What the rewrite is actually handed - "one of them thought it
        was an agency retainer" names the paragraph that has to change, and a
        bare count does not."""
        return [read for read in self.reported if not read.understood]

    @property
    def landed(self) -> bool:
        """Whether the panel would click: more than half of the readers who
        reported back would have.

        Not unanimity. Giving every reader a veto sounds like a higher
        standard and is really an unreachable one - the loop then always
        exhausts its rewrites, and "we ran out of rewrites" reaches the user
        as if it were the copy's score. One holdout in three is what copy that
        works looks like; two is a draft with a real problem.
        """
        landed = sum(1 for read in self.reported if read.landed)
        return bool(self.reported) and self.relevant and landed * 2 > len(self.reported)

    @property
    def worst(self) -> BlindRead:
        """The hardest verdict anyone actually gave. A reader who never came
        back has no verdict, and must not be counted as the harshest one."""
        return min(self.reported, key=lambda read: read.pull, default=BlindRead())

    @property
    def primary(self) -> BlindRead:
        return self.reads[0] if self.reads else BlindRead()

    def verdict_line(self) -> str:
        """What the panel would do, in one phrase for a timeline row.

        Here rather than at each call site: the craft loop and the persistence
        observer each used to build this sentence from `primary` alone, which
        printed one reader's answer beside the whole panel's score.
        """
        reported = self.reported
        if not reported:
            return "nobody could read it"
        if not self.relevant:
            return "AI simulation detected an audience mismatch"
        if (lost := len(self.confused)) :
            # Said first and instead of the frequency, because the frequency
            # is an estimate of what people do with an email they understood.
            return (
                f"{lost} of {len(reported)} could not say what it was"
                if len(reported) > 1
                else "they could not say what it was"
            )
        return f"AI simulation assessment {self.pull:.0f}/10 (uncalibrated)"

    def render(self) -> str:
        if len(self.reads) == 1:
            return self.reads[0].render()
        return "\n\n".join(
            f"Reader: {read.persona or 'unnamed'}\n{read.render()}" for read in self.reads
        )


class BlindReader:
    def __init__(self, session: ModelSession) -> None:
        self._session = session

    async def read(self, email: Email, personas: list[str]) -> PanelRead:
        """Every persona reads the same draft, at the same time.

        Concurrently because they are genuinely independent: no reader sees
        another's report, which is the whole point of a panel. Read in
        sequence, a three-person panel spent three model calls' worth of
        wall-clock on a step that costs the same either way - in a measured
        run, a bake-off read took nearly four minutes. `gather` preserves
        input order, so the panel's membership stays stable across a run.
        """
        chosen = personas or [_FALLBACK_PERSONA]
        reads = await asyncio.gather(
            *(self._read_once(email, persona) for persona in chosen)
        )
        return PanelRead(reads=list(reads))

    async def _read_once(self, email: Email, persona: str) -> BlindRead:
        # The reader's whole prompt is who they are and what arrived. Rendered
        # here rather than by the session's template path because the email
        # under review is part of the system prompt, not the task.
        system_prompt = self._session.render(
            "reader", {"reader_profile": persona, "email": render_review(email)}
        )
        try:
            assessment = await self._session.structured(
                role=ROLE_ID,
                tier=ModelTier.BALANCED,
                system_prompt=system_prompt,
                task="React now, as the person described above, reading this for the first time.",
                schema=ReaderAssessment,
            )
            read = BlindRead.model_validate(assessment.model_dump())
        except ModelRuntimeError as exc:
            # A reader who could not report is not a reason to throw away a
            # draft: it is no verdict, and the copy stands on the other
            # checks. What it must never become is a passing score - scoring
            # the failure at the threshold shipped drafts nobody had read,
            # and averaged a number nobody had given into the campaign's
            # headline result.
            #
            # Every runtime failure, not only a malformed answer. A panel is
            # read concurrently, so a transport failure on one of three
            # personas used to escape `gather` and take the whole campaign
            # down - past the craft loop, past the pipeline (which catches
            # `CampaignError`, and this is not one), and into the
            # orchestrator's crash handler, which discards every email the run
            # had already finished. One reader out of three not coming back is
            # exactly the case `reported=False` was built for.
            logger.info("reader: a cold read did not come back - %s", exc)
            return BlindRead(
                reported=False,
                persona=persona,
                what_it_sells="(the reader did not report)",
            )
        read.persona = persona
        return read


_FALLBACK_PERSONA = "a busy professional who has never heard of this company"


def personas_for(
    audience: AudienceModel, chosen: Segment | None, panel: bool, explicit_audience: str = "",
    reader_scope: str = "",
) -> list[str]:
    """Who reads the draft cold.

    Never the brief's reader description - that sentence was written to help a
    writer and is full of intent. A cold reader is a person, described only as
    a person. But it must be the *right* person: `chosen` is the segment the
    Strategist decided this campaign is for, and reading the copy as anyone
    else measures the mismatch instead of the copy.

    A panel varies the reader's disposition, never their identity. Handing the
    same draft to two different segments looks like more coverage and is the
    opposite: a panel that spans segments can only be satisfied by copy vague
    enough to work on all of them, and the rewrite loop spends its budget
    sanding a specific email into a general one.

    The dispositions change what the reader scrutinises, not what happened to
    them. Inventing an installed tool or a failed purchase changes their needs
    and can turn a suitable launch email into an apparent audience mismatch.
    """
    segment = chosen or audience.primary()
    person = (
        f"Selected audience (explicit constraints): {segment.name}.\n"
        "The context and problem reports below describe observed members of this market, "
        "not established experiences or installed tools of this recipient. The campaign "
        "request controls which job this email addresses; do not require a link to an "
        "unrequested integration in your doubts or click requirements.\n"
        f"Observed context ({segment.situation_grounding}; applicability must be checked): {segment.situation}\n"
        + "\n".join(f"Source: {p.source}; quote: {p.quote}" for p in segment.situation_provenance)
        + "\n"
        + "\n".join(
            f"Problem context: {p.render()}; "
            f"source: {p.provenance.source if p.provenance else 'unknown'}"
            for p in segment.pains
        )
        if segment is not None and segment.name
        else _FALLBACK_PERSONA
    )
    if explicit_audience.strip():
        person = (
            f"Selected audience (user-stated constraints): {explicit_audience.strip()}.\n"
            "Only these audience facts are established. Do not substitute a compiled "
            "market segment, invent an installed tool or experience, or infer the "
            "campaign's desired reaction. Read the email cold as this person."
        )
    elif reader_scope.strip():
        person += (
            "\nQualified scope of the selected audience: " + reader_scope.strip()
            + ". This narrows who you are; it does not establish installed tools, prior actions or desired reactions."
        )
    if not panel:
        return [person]
    # The variants are dispositions the same person turns up in. The hard one
    # is added rather than found: an audience model describes people who might
    # buy, and the reader who nearly would not is the one whose objection the
    # copy has to survive.
    return [
        person,
        (
            f"{person}\nReading emphasis: weigh the effort of the next step against its "
            "usefulness. Do not assume an installed tool, a switching project or an "
            "existing workflow beyond the profile."
        ),
        (
            f"{person}\nReading emphasis: scrutinise whether the claims earn trust for "
            "the requested next step. Do not invent a prior purchase, failed tool or "
            "bad experience; distinguish trying the product from adopting it in production."
        ),
    ]
