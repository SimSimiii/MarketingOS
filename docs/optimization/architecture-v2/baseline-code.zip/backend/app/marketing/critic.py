"""The Conversion Critic: what the reader felt, turned into what to change.

The blind reader reports behavior - they stopped here, they could not say what
it sells, they would not click today. That is evidence, not instruction.
Somebody has to decide what to do about it, and it cannot be the writer: the
writer knows what it meant, and reads its own draft as if the meaning were on
the page.

So the critic is a separate role with a separate context: the brief, the
ledger, the reader's report and the gate results, but not the writer's
reasoning and not its earlier attempts. Its independence is why it can see
brief drift - an email that reads beautifully and argues the wrong thing - and
unspent evidence, both of which are invisible from inside the draft.

It replaces the old outer review agent, which scored a truncated JSON digest
of the whole campaign against a rubric that half-duplicated the free
mechanical checks. This one reads one rendered email and names lines.
"""

from typing import Literal

from pydantic import BaseModel, Field, model_validator

from app.ai.model_router import ModelTier
from app.knowledge.artifacts import KnowledgeArtifacts
from app.marketing.briefs import CampaignBrief, EmailBrief
from app.marketing.email_copy import Email, render_review
from app.marketing.gates import GateReport
from app.marketing.reader import PanelRead
from app.marketing.substantiation import Substantiation
from app.runtime.model_session import ModelSession

ROLE_ID = "conversion_critic"

#: How many non-blocking edits reach the writer in one pass.
#:
#: Not a limit on what the critic may notice - everything it found is recorded
#: and shown to the user. It is a limit on what one rewrite is asked to do.
#: Handed ten edits, a writer does not revise, it rewrites: the draft that
#: comes back is a different email, which draws a different ten edits, and the
#: loop spends its whole budget replacing drafts instead of improving one. The
#: edits are ranked most damaging first, so the top few are the ones worth the
#: turn, and whatever still matters will be found again on the next read.
MAX_EDITS_PER_PASS = 3


class Edit(BaseModel):
    """One thing to change, anchored to the line it is about."""

    #: Quoted from the email, so the writer cannot mistake which line.
    line: str = ""
    problem: str = ""
    #: What the fix must achieve - never the replacement copy. The critic
    #: diagnosing and the writer prescribing is how a draft keeps one voice.
    fix: str = ""
    severity: Literal["blocking", "major", "minor"] = "major"

    def render(self) -> str:
        anchor = f'"{self.line}" - ' if self.line else ""
        return f"({self.severity}) {anchor}{self.problem} → {self.fix}"


class Critique(BaseModel):
    verdict: Literal["ship", "revise"] = "revise"
    #: Why this draft cannot ship. A prose defect can be rewritten from the
    #: same brief; an argument defect or missing fact cannot. Keeping that
    #: distinction structured prevents the loop from asking a writer to invent
    #: a guide, compatibility guarantee or proof that is absent upstream.
    failure_mode: Literal["none", "copy", "argument", "missing_material"] = "copy"
    #: The exact unsupported decision or missing resource. Persisted on the
    #: outcome and receipt when another writing pass cannot resolve it.
    strategy_gap: str = ""
    #: Where the draft executes something other than its brief. The failure
    #: that is invisible from inside the copy.
    brief_drift: str = ""
    #: Evidence this email was given and did not use.
    unspent_evidence: list[str] = Field(default_factory=list)
    edits: list[Edit] = Field(default_factory=list)
    summary: str = ""

    @property
    def blocking(self) -> list[Edit]:
        return [edit for edit in self.edits if edit.severity == "blocking"]

    @property
    def for_this_pass(self) -> list[Edit]:
        """The edits one rewrite is actually asked to make.

        Everything blocking, because a blocking edit is why the email cannot
        ship, plus the most damaging of the rest up to `MAX_EDITS_PER_PASS`.
        Order is the critic's own ranking, preserved.
        """
        room = MAX_EDITS_PER_PASS - len(self.blocking)
        kept: list[Edit] = []
        for edit in self.edits:
            if edit.severity == "blocking":
                kept.append(edit)
            elif room > 0:
                kept.append(edit)
                room -= 1
        return kept

    def render(self) -> str:
        parts: list[str] = []
        if self.failure_mode in {"argument", "missing_material"}:
            label = "Argument cannot be repaired by copy" if self.failure_mode == "argument" else "Missing material"
            parts.append(f"{label}: {self.strategy_gap or self.summary or 'not specified'}")
        if self.brief_drift:
            parts.append(f"Brief drift: {self.brief_drift}")
        if self.unspent_evidence:
            parts.append(f"Evidence assigned but unused: {', '.join(self.unspent_evidence)}")
        shown = self.for_this_pass
        if shown:
            parts.append("\n".join(f"- {edit.render()}" for edit in shown))
        held_back = len(self.edits) - len(shown)
        if held_back:
            parts.append(
                f"({held_back} smaller note(s) held back - fix the ones above first. A rewrite "
                "that tries to answer every note at once comes back as a different email.)"
            )
        if self.summary:
            parts.append(self.summary)
        return "\n".join(parts) or "No changes requested."

    @property
    def requires_new_strategy(self) -> bool:
        return self.verdict == "revise" and self.failure_mode in {
            "argument",
            "missing_material",
        }


class CritiqueDecision(Critique):
    """The response contract shown to the model.

    ``Critique`` keeps defaults because tests, stored records and callers build
    it directly.  Defaults are harmful in the model-facing schema, though: the
    critic can describe a proposition that needs rebuilding while silently
    inheriting ``copy``.  These three fields are therefore required on every
    live decision, and contradictory combinations are rejected for the normal
    structured-output repair pass to correct.
    """

    verdict: Literal["ship", "revise"] = Field(
        description="Whether the email can be sent to a paying client's list as written."
    )
    failure_mode: Literal["none", "copy", "argument", "missing_material"] = Field(
        description="The level at which the defect must be repaired."
    )
    strategy_gap: str = Field(
        description=(
            "The exact proposition or material gap for argument/missing_material; "
            "an empty string for ship or copy."
        )
    )

    @model_validator(mode="after")
    def _consistent_route(self) -> "CritiqueDecision":
        gap = self.strategy_gap.strip()
        if self.verdict == "ship":
            if self.failure_mode != "none" or gap:
                raise ValueError("a shipping email must use failure_mode=none and no strategy_gap")
            return self
        if self.failure_mode == "none":
            raise ValueError("a revision must identify copy, argument, or missing_material")
        if self.failure_mode in {"argument", "missing_material"} and not gap:
            raise ValueError("a strategy or material failure must name strategy_gap")
        if self.failure_mode == "copy" and gap:
            raise ValueError("a copy-only revision cannot also name a strategy_gap")
        return self


class ConversionCritic:
    def __init__(self, session: ModelSession) -> None:
        self._session = session

    async def critique(
        self,
        *,
        email: Email,
        brief: EmailBrief,
        campaign: CampaignBrief,
        artifacts: KnowledgeArtifacts,
        read: PanelRead,
        gates: GateReport,
        substantiation: Substantiation | None = None,
        source_context: str = "",
    ) -> Critique:
        segment = artifacts.audience.match(campaign.reader_segment, campaign.reader)
        return await self._session.structured(
            role=ROLE_ID,
            tier=ModelTier.DEEP,
            template="critic",
            variables={
                "email": render_review(email),
                "brief": brief.render(),
                "reader": campaign.reader,
                "segment": segment.render_for_writing() if segment else "Not established.",
                "campaign_intent": campaign.interpretation,
                "cta_destination": campaign.fixed_cta_url or "No fixed destination; use the supported brief.",
                "orientation": campaign.orientation,
                "promise": campaign.promise,
                # The same slice the writer wrote from. The critic's job here
                # is to notice evidence this email needed and did not spend -
                # and against the full ledger of a real business that question
                # has a hundred answers, every one of them a reason to add
                # another sentence. It is the additive ratchet with a budget
                # line attached.
                "evidence": artifacts.evidence_for_writing(
                    brief.evidence_ids,
                    brief.objection,
                    offering=campaign.orientation,
                    excluded_ids=frozenset(brief.forbidden_evidence_ids),
                ).render(),
                "voice": artifacts.voice.render(),
                "reader_report": read.render(),
                "gate_report": gates.render(),
                # Which assigned facts are absent from the page is a string
                # comparison, and it is already done - see
                # app.marketing.substantiation. Handing the critic the answer
                # rather than the question is the same trade the rest of the
                # system makes everywhere else: a model asked to re-derive a
                # lookup answers it approximately, and spends the attention it
                # owed to brief drift doing it. What is left for the critic is
                # the part that is judgment - whether this email's argument
                # actually needed the fact it left out.
                "unspent_evidence": _unspent(substantiation),
            },
            task=(
                "Decide whether this email ships as it stands, and if not, name the lines that "
                "have to change and what each change has to achieve."
                + ("\n\n" + source_context if source_context else "")
            ),
            schema=CritiqueDecision,
        )


def _unspent(substantiation: Substantiation | None) -> str:
    if substantiation is None or not substantiation.unspent:
        return (
            "Every fact this email was assigned is on the page (or it was assigned none). "
            "There is nothing to add back."
        )
    listing = "\n".join(
        f"- [{entry.id}] {entry.claim}" for entry in substantiation.unspent
    )
    return (
        "These were assigned to this email and no trace of them reached the page - not the "
        f"figure, not the name, not the quotation:\n{listing}"
    )
