from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status

from app.ai.roles import InvalidOverrideError
from app.api.deps import CampaignServiceDep
from app.core.config import get_settings
from app.schemas.campaign import (
    CampaignBriefUpdate,
    CampaignCreateRequest,
    CampaignExecutionRead,
    CampaignGenerationAdvice,
    CampaignPolicyUpdate,
    CampaignRead,
    CampaignStartRequest,
    RunForecast,
)
from app.services.campaign_service import (
    CampaignAlreadyRunningError,
    CampaignTargetError,
    NoExecutionToRestartError,
)

router = APIRouter(prefix="/campaigns", tags=["campaigns"])


@router.post("", response_model=CampaignRead, status_code=status.HTTP_201_CREATED)
def create_campaign(data: CampaignCreateRequest, service: CampaignServiceDep) -> CampaignRead:
    if get_settings().credit_billing_enabled and data.channel is not None:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "Only email campaigns are available.")
    if get_settings().credit_billing_enabled and data.model_overrides:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "Model selection is managed by the service.")
    try:
        campaign = service.create_campaign(data)
    except (InvalidOverrideError, CampaignTargetError) as exc:
        # 422, not 400: the body parsed fine and one field in it is not
        # satisfiable. The message names the agent and the model, so the dialog
        # can put it next to the row the user got wrong.
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
    return CampaignRead.model_validate(campaign)


@router.get("", response_model=list[CampaignRead])
def list_campaigns(
    service: CampaignServiceDep, include_archived: bool = False,
    limit: int = Query(100, ge=1, le=250), offset: int = Query(0, ge=0),
    brand_id: UUID | None = None,
) -> list[CampaignRead]:
    rows = service.list_campaigns(include_archived, limit=limit, offset=offset, brand_id=brand_id)
    latest = service.latest_run_by_campaign([row.id for row in rows])
    campaigns = []
    for campaign in rows:
        read = CampaignRead.model_validate(campaign)
        run = latest.get(campaign.id)
        if run is not None:
            read.last_run_status, read.last_run_at, read.last_run_needs_review = run
        campaigns.append(read)
    return campaigns


@router.get("/{campaign_id}", response_model=CampaignRead)
def get_campaign(campaign_id: UUID, service: CampaignServiceDep) -> CampaignRead:
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return CampaignRead.model_validate(campaign)


@router.delete("/{campaign_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_campaign(campaign_id: UUID, service: CampaignServiceDep) -> None:
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    try:
        service.delete_campaign(campaign)
    except CampaignAlreadyRunningError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc


@router.post("/{campaign_id}/archive", response_model=CampaignRead)
def archive_campaign(campaign_id: UUID, service: CampaignServiceDep) -> CampaignRead:
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return CampaignRead.model_validate(service.archive_campaign(campaign))


@router.post("/{campaign_id}/unarchive", response_model=CampaignRead)
def unarchive_campaign(campaign_id: UUID, service: CampaignServiceDep) -> CampaignRead:
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return CampaignRead.model_validate(service.unarchive_campaign(campaign))


@router.post("/{campaign_id}/duplicate", response_model=CampaignRead, status_code=status.HTTP_201_CREATED)
def duplicate_campaign(campaign_id: UUID, service: CampaignServiceDep) -> CampaignRead:
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return CampaignRead.model_validate(service.duplicate_campaign(campaign))


@router.put("/{campaign_id}/policy", response_model=CampaignRead)
def update_campaign_policy(
    campaign_id: UUID, data: CampaignPolicyUpdate, service: CampaignServiceDep
) -> CampaignRead:
    if get_settings().credit_billing_enabled and data.model_overrides:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, "Model selection is managed by the service.")
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    try:
        updated = service.update_policy(campaign, data)
    except (InvalidOverrideError, ValueError) as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
    return CampaignRead.model_validate(updated)


@router.get("/{campaign_id}/forecast", response_model=RunForecast)
def forecast_campaign(campaign_id: UUID, service: CampaignServiceDep) -> RunForecast:
    """What this campaign will cost to run, before it is run.

    Free and instant: nothing here calls a model. The pipeline is a state
    machine, so the number of model calls a run makes follows from the preset
    and from the number of emails the request asks for - and the money beside
    it is what this user's own past runs on this preset actually cost.
    """
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return service.forecast_run(campaign)


@router.get(
    "/{campaign_id}/generation-advice",
    response_model=CampaignGenerationAdvice,
)
def campaign_generation_advice(
    campaign_id: UUID, service: CampaignServiceDep
) -> CampaignGenerationAdvice:
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return service.generation_advice(campaign)


@router.post(
    "/{campaign_id}/start",
    response_model=CampaignExecutionRead,
    status_code=status.HTTP_202_ACCEPTED,
)
async def start_campaign(
    campaign_id: UUID,
    service: CampaignServiceDep,
    data: CampaignStartRequest | None = None,
) -> CampaignExecutionRead:
    """Hand the campaign to the pipeline. Returns immediately with
    the new execution in RUNNING state - the run itself continues in the
    background; poll GET /executions/{id}/status or open
    GET /executions/{id}/stream to watch it happen live."""
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    if get_settings().credit_billing_enabled and campaign.channel is not None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "This feature is unavailable.")
    try:
        execution = await service.start_execution(
            campaign, generate_anyway=data.generate_anyway if data else False
        )
    except CampaignAlreadyRunningError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    except CampaignTargetError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
    return CampaignExecutionRead.model_validate(execution)


@router.put("/{campaign_id}/brief", response_model=CampaignRead)
def update_campaign_brief(
    campaign_id: UUID, data: CampaignBriefUpdate, service: CampaignServiceDep
) -> CampaignRead:
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    try:
        return CampaignRead.model_validate(service.update_brief(campaign, data))
    except CampaignAlreadyRunningError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc


@router.post(
    "/{campaign_id}/restart",
    response_model=CampaignExecutionRead,
    status_code=status.HTTP_202_ACCEPTED,
)
async def restart_campaign(
    campaign_id: UUID,
    service: CampaignServiceDep,
    data: CampaignStartRequest | None = None,
) -> CampaignExecutionRead:
    """Start a fresh run of a campaign that has run before (typically after
    a failed or cancelled execution) - same as /start, but 404s instead of
    silently behaving like a first run when there is nothing to restart."""
    campaign = service.get_campaign(campaign_id)
    if campaign is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    if get_settings().credit_billing_enabled and campaign.channel is not None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "This feature is unavailable.")
    try:
        execution = await service.restart_execution(
            campaign, generate_anyway=data.generate_anyway if data else False
        )
    except NoExecutionToRestartError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    except CampaignAlreadyRunningError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    except CampaignTargetError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, str(exc)) from exc
    return CampaignExecutionRead.model_validate(execution)


@router.get("/{campaign_id}/executions", response_model=list[CampaignExecutionRead])
def list_campaign_executions(
    campaign_id: UUID, service: CampaignServiceDep
) -> list[CampaignExecutionRead]:
    # The only route here that reached past the campaign without loading it -
    # the run list would have answered for any id, which is a readable handle
    # on somebody else's campaign history.
    if service.get_campaign(campaign_id) is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Campaign not found")
    return [CampaignExecutionRead.model_validate(e) for e in service.list_executions(campaign_id)]
