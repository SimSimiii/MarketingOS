from fastapi import APIRouter

from app.api.routes import (
    auth,
    brands,
    campaigns,
    credits,
    email_analysis,
    executions,
    health,
    knowledge,
    linkedin,
    logs,
    market,
    models,
    settings,
)

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(brands.router)
api_router.include_router(campaigns.router)
api_router.include_router(credits.router)
api_router.include_router(email_analysis.router)
api_router.include_router(executions.router)
api_router.include_router(knowledge.router)
api_router.include_router(market.router)
api_router.include_router(linkedin.router)
api_router.include_router(models.router)
api_router.include_router(settings.router)
api_router.include_router(logs.router)
