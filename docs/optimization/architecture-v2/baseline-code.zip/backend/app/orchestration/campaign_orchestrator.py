import hashlib
import logging
import time
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlmodel import Session, select

from app.ai.base import AIProvider
from app.ai.model_router import ModelRouter
from app.ai.roles import WILDCARD_ROLE
from app.core.config import PROMPTS_DIR
from app.ingestion.documents import SourceType
from app.knowledge.artifacts import KnowledgeArtifacts
from app.knowledge.corpus import SourceCorpus
from app.knowledge.store import ArtifactScope, ArtifactStore, StoredArtifacts, fingerprint_documents
from app.market.demand import DemandMap
from app.market.material_research import MaterialRecovery
from app.market.positioning import PositioningMap, build_current
from app.market.store import (
    MarketStore,
    merge_audience,
    merge_proof,
    prospect_qualification,
)
from app.marketing.briefs import CampaignBrief
from app.marketing.cancellation import CancellationToken
from app.marketing.craft import EmailVersion
from app.marketing.critic import Critique
from app.marketing.email_copy import Email
from app.marketing.gates import GateReport
from app.marketing.intelligence import (
    CampaignIntelligenceBundle,
    adapt_researched_audience,
    build_campaign_intelligence,
    resolve_audience_research,
)
from app.marketing.linkedin import ROLE_ID as LINKEDIN_WRITER_ROLE
from app.marketing.observer import RunObserver
from app.marketing.pipeline import (
    CampaignRunResult,
    EmailCampaignPipeline,
    KnowledgeGateway,
)
from app.marketing.policy import ExecutionPolicy, resolve_policy
from app.marketing.preflight import PROOF_KINDS
from app.marketing.reader import PanelRead
from app.marketing.render_html import (
    MAX_EMAIL_BYTES,
    BrandStyle,
    EmailTier,
    render_html,
    style_for_action,
    text_alternative,
)
from app.marketing.report import CampaignReport
from app.marketing.request import CampaignRequest
from app.marketing.sequence import SequenceReport
from app.models.agent_execution import AgentExecution
from app.models.campaign import Campaign
from app.models.campaign_execution import CampaignExecution
from app.models.enums import AssetType, ExecutionStatus, LogLevel
from app.models.generated_asset import GeneratedAsset
from app.models.knowledge_document import KnowledgeDocument
from app.models.market import ProspectRow
from app.orchestration.event_emitter import ExecutionEventEmitter
from app.orchestration.live_broker import broker
from app.repositories.agent_execution_repository import AgentExecutionRepository
from app.repositories.brand_repository import BrandRepository
from app.repositories.campaign_execution_repository import CampaignExecutionRepository
from app.repositories.campaign_repository import CampaignRepository
from app.repositories.execution_log_repository import ExecutionLogRepository
from app.repositories.generated_asset_repository import GeneratedAssetRepository
from app.repositories.knowledge_repository import KnowledgeDocumentRepository
from app.runtime.events import (
    EventBus,
    ModelCallFinished,
    ModelCallRetried,
    ModelCallStarted,
)
from app.runtime.model_session import ModelSession, RoleCall
from app.runtime.prompt_engine import get_prompt_engine
from app.schemas.linkedin import LinkedInChannel
from app.services.market_service import MarketService

logger = logging.getLogger("marketingos.orchestration")

#: Statuses that still handed the user usable emails. A run that timed out
#: after writing four of five did not fail - it delivered four, and saying
#: otherwise hides real work behind a red banner.
_DELIVERING_STATUSES = {
    "completed",
    "degraded",
    "timed_out",
    "budget_exhausted",
    "provider_unavailable",
}

#: Human names for the five reasoning roles, for the timeline. The old system
#: read these off an agent registry; there is no registry now because there is
#: nothing to look up at runtime - the roles are fixed.
ROLE_NAMES: dict[str, str] = {
    "knowledge_compiler": "Knowledge Compiler",
    "strategist": "Strategist",
    "email_writer": "Email Writer",
    "blind_reader": "Blind Reader",
    "conversion_critic": "Conversion Critic",
    "sequence_reviewer": "Sequence Reviewer",
    "preference_judge": "Side-by-Side Reader",
    "subject_writer": "Subject Lines",
    "inbox_scanner": "Inbox Glance",
    "material_researcher": "Official Material Researcher",
}


def role_name(role_id: str) -> str:
    return ROLE_NAMES.get(role_id, role_id.replace("_", " ").title())


class _DbKnowledgeGateway(KnowledgeGateway):
    """The pipeline's window onto stored knowledge, backed by the database."""

    def __init__(self, session: Session, campaign: Campaign) -> None:
        self._store = ArtifactStore(session)
        self._session = session
        self._campaign = campaign
        self._scope = ArtifactScope.for_campaign(campaign)
        self._documents = self._store.source_documents(self._scope)
        self._corpus: SourceCorpus | None = None
        self._market = MarketStore(session) if campaign.brand_id is not None else None

    @property
    def scope(self) -> ArtifactScope:
        return self._scope

    def corpus(self) -> SourceCorpus:
        if self._corpus is None:
            self._corpus = self._store.corpus_for(self._scope)
        return self._corpus

    def fingerprint(self) -> str:
        return fingerprint_documents(self._documents)

    def load(self) -> StoredArtifacts | None:
        stored = self._store.load(self._scope)
        return self._with_market(stored)

    def save(self, artifacts: KnowledgeArtifacts, fingerprint: str) -> StoredArtifacts:
        return self._with_market(self._store.save(self._scope, artifacts, fingerprint))

    def commit_recovered_material(
        self, recovery: MaterialRecovery, artifacts: KnowledgeArtifacts
    ) -> StoredArtifacts:
        """File verified pages and the enriched ledger without another compile."""

        repository = KnowledgeDocumentRepository(self._session)
        enriched = artifacts.model_copy(deep=True)
        by_hash = {
            hashlib.sha256(document.content.encode("utf-8")).hexdigest(): document
            for document in self._documents
        }
        persisted_ids: list[str] = []
        source_documents: dict[str, str] = {}
        for source in recovery.sources:
            document = by_hash.get(source.content_hash)
            if document is None:
                document = repository.create(
                    KnowledgeDocument(
                        owner_id=self._campaign.owner_id,
                        brand_id=self._scope.brand_id,
                        campaign_id=self._scope.campaign_id,
                        title=source.title or source.final_url,
                        source_type=SourceType.WEBSITE,
                        content=source.content,
                        source_url=source.final_url,
                        word_count=len(source.content.split()),
                        document_metadata={
                            "automatically_discovered": True,
                            "recovered_for": recovery.gap,
                            "content_hash": source.content_hash,
                        },
                    )
                )
                self._documents.append(document)
                by_hash[source.content_hash] = document
            document_id = str(document.id)
            persisted_ids.append(document_id)
            source_documents[source.final_url.rstrip("/").lower()] = document_id

        enriched.source_document_ids = [
            item for item in enriched.source_document_ids if not item.startswith("auto:")
        ]
        for document_id in persisted_ids:
            if document_id not in enriched.source_document_ids:
                enriched.source_document_ids.append(document_id)
        for entry in enriched.evidence.entries:
            if document_id := source_documents.get(entry.source.rstrip("/").lower()):
                entry.document_id = document_id

        self._corpus = self._store.corpus_for(self._scope)
        stored = self._store.save(
            self._scope,
            enriched,
            fingerprint_documents(self._documents),
        )
        return self._with_market(stored) or stored

    def positioning(self) -> PositioningMap | None:
        """The latest market scan for this brand, if there is one.

        Brand-scoped only. A one-off campaign with no brand has nowhere to
        keep a competitor list between runs, so scanning for it would buy a
        reading that is thrown away with the campaign.
        """
        if self._market is None or self._campaign.brand_id is None:
            return None
        snapshot = self._market.latest_scan(self._campaign.brand_id)
        if snapshot is None:
            return None
        if (stored := self.load()) is None:
            return snapshot.positioning
        return build_current(
            stored.artifacts, snapshot.rivals,
            we_have_proof=bool(stored.artifacts.evidence.of_kind(*PROOF_KINDS)),
        )

    def demand(self) -> DemandMap | None:
        """The latest audience map for this brand, if there is one.

        Brand-scoped for the same reason the positioning is: a one-off
        campaign has nowhere to keep a map between runs.
        """
        if self._market is None or self._campaign.brand_id is None:
            return None
        return self._market.latest_map(self._campaign.brand_id)

    def audience_choice(self) -> str:
        return self._campaign.audience_segment or ""

    def campaign_intelligence(
        self, artifacts: KnowledgeArtifacts
    ) -> CampaignIntelligenceBundle | None:
        """Resolve one selected researched audience without creating anything."""
        if self._market is None or self._campaign.brand_id is None:
            return None
        selected = (self._campaign.audience_segment or "").strip()
        if not selected:
            return None

        match = resolve_audience_research(
            selected,
            self._market.latest_researches(self._campaign.brand_id),
        )
        dossier_status = None
        if match.research is not None:
            dossier_status = MarketService(self._session).relevance_status(
                self._campaign.brand_id, match.research.audience_name
            )
        context = build_campaign_intelligence(
            selected_audience=selected,
            match=match,
            dossier_status=dossier_status,
            ledger=artifacts.evidence,
        )
        if self._campaign.prospect_id is not None:
            prospect = self._session.get(ProspectRow, self._campaign.prospect_id)
            if prospect is not None and prospect.brand_id == self._campaign.brand_id:
                context.selected_company_name = prospect.name
                context.selected_company_url = prospect.url
                context.selected_company_qualification = prospect_qualification(prospect)
        adapted = (
            adapt_researched_audience(artifacts, match.research, context)
            if match.research is not None
            else artifacts
        )
        return CampaignIntelligenceBundle(artifacts=adapted, context=context)

    def _with_market(self, stored: StoredArtifacts | None) -> StoredArtifacts | None:
        """Fold in what the market pages decided, on top of what was compiled.

        Two merges, both at read time rather than written into the stored set,
        so a recompile cannot lose either - see `app.market.store`.

        The first is every third-party proof the user has approved: this is
        where a testimonial they ticked in the UI becomes a fact the writer
        may spend and the evidence gate will license.

        The second is the audience segment this campaign was pointed at, which
        goes to the head of the audience model. That single move is what makes
        the choice reach the copy: the strategist plans against it, the cold
        reader panel is built from it, and the critic grades against it, none
        of them knowing where it came from.

        Version and fingerprint are carried through untouched. They describe
        the *material* this was compiled from, and neither merge changed any
        material - treating them as changed would recompile the business every
        time somebody targeted a different buyer.
        """
        if stored is None or self._market is None or self._campaign.brand_id is None:
            return stored
        artifacts = stored.artifacts
        if approved := self._market.approved_evidence(self._campaign.brand_id):
            artifacts = merge_proof(artifacts, approved)
        if chosen := (self._campaign.audience_segment or ""):
            artifacts = merge_audience(
                artifacts, self._market.segment_named(self._campaign.brand_id, chosen)
            )
        if artifacts is stored.artifacts:
            return stored
        return StoredArtifacts(
            artifacts=artifacts,
            version=stored.version,
            fingerprint=stored.fingerprint,
        )

    def prior_learnings(self) -> str:
        """What the last finished campaign for this business found out.

        Only the most recent one: a Strategist reading five campaign reports
        spends its attention on history instead of on this campaign, and the
        newest report already carries forward the gaps that survived.
        """
        executions = CampaignExecutionRepository(self._session)
        campaigns = [self._campaign]
        if self._campaign.brand_id is not None:
            campaigns = CampaignRepository(self._session).list_by_brand(self._campaign.brand_id)

        for campaign in campaigns:
            for execution in executions.list_by_campaign(campaign.id):
                payload = (execution.result or {}).get("report")
                if not payload:
                    continue
                try:
                    return CampaignReport.model_validate(payload).render_learnings()
                except Exception:
                    logger.info("could not read a prior campaign report", exc_info=True)
        return ""


class _PersistenceObserver(RunObserver):
    """Watches the pipeline and persists what happened.

    The pipeline itself knows nothing about databases. Every hook goes through
    the execution's event emitter, so a watching client sees the same story the
    database will hold - that single funnel is the reason the live stream and
    a reloaded page can never disagree, and it survives the redesign untouched.

    A "step" here is one role invocation: one writer turn, one cold read, one
    critique. That is finer-grained than the old director's steps and more
    honest, because it is also the unit that costs money.
    """

    def __init__(
        self,
        orchestrator: "CampaignOrchestrator",
        execution: CampaignExecution,
        emitter: ExecutionEventEmitter,
    ) -> None:
        self._orchestrator = orchestrator
        self._execution = execution
        self._emitter = emitter
        self._step = 0
        self._open: dict[str, Any] | None = None
        self._calls: list[RoleCall] = []
        #: Which AgentExecution row last wrote each email, so the finished
        #: asset can be attached to the run that produced it.
        self.writer_rows: dict[int, UUID] = {}
        self.attempts: dict[str, int] = {}

    # ------------------------------------------------------------ recording

    def record_call(self, call: RoleCall) -> None:
        """Every model call lands in whichever step is currently open."""
        self._calls.append(call)

    def on_phase(self, phase: str, message: str, data: dict[str, Any] | None = None) -> None:
        self._emitter.emit(
            "phase",
            message,
            agent_id=self._open["role_id"] if self._open else None,
            data={"phase": phase, **(data or {})},
        )

    def on_role_started(
        self, role_id: str, label: str, data: dict[str, Any] | None = None
    ) -> None:
        if self._open is not None:
            # Defensive: a role that never reported finishing would otherwise
            # swallow the next one's tokens.
            self.on_role_finished(self._open["role_id"], "finished")
        self._step += 1
        self.attempts[role_id] = self.attempts.get(role_id, 0) + 1
        self._calls = []
        self._open = {
            "role_id": role_id,
            "label": label,
            "step": self._step,
            "started_at": datetime.now(UTC),
            "data": data or {},
        }
        self._emitter.current_step = self._step
        self._emitter.emit(
            "agent_started",
            f"{role_name(role_id)}: {label}",
            agent_id=role_id,
            step=self._step,
            data={"agent_name": role_name(role_id), "label": label, **(data or {})},
        )

    def on_role_finished(
        self, role_id: str, summary: str, output: dict[str, Any] | None = None
    ) -> None:
        open_step = self._close()
        if open_step is None:
            return
        row = self._persist_row(
            open_step, ExecutionStatus.COMPLETED, output_data=output, error=None
        )
        if role_id in {"email_writer", LINKEDIN_WRITER_ROLE}:
            # The LinkedIn writer produces the run's only deliverable, so its
            # row is position 1 - the same slot the first email would take, and
            # the one `_persist_assets` falls back to.
            position = open_step["data"].get("position", 1)
            if position is not None:
                self.writer_rows[int(position)] = row.id
        self._emitter.emit(
            "agent_completed",
            f"{role_name(role_id)}: {summary}",
            agent_id=role_id,
            step=open_step["step"],
            agent_execution_id=row.id,
            data={
                "agent_name": role_name(role_id),
                "agent_execution_id": str(row.id),
                "model": row.model,
                # The billable figure, not the uncached remainder: a step that
                # reports "2 input tokens" beside a 30,000-character prompt
                # teaches the user the wrong thing about what a run costs.
                "input_tokens": row.input_tokens
                + row.cache_creation_input_tokens
                + row.cache_read_input_tokens,
                "output_tokens": row.output_tokens,
                "cache_read_input_tokens": row.cache_read_input_tokens,
                "cost_usd": row.cost_usd,
                "duration_ms": row.duration_ms,
                "attempt": row.attempt,
                "summary": summary,
                "assets_produced": [],
            },
        )

    def on_role_failed(self, role_id: str, error: str) -> None:
        open_step = self._close()
        if open_step is None:
            self._emitter.emit("run_error", error, level=LogLevel.ERROR, agent_id=role_id)
            return
        row = self._persist_row(open_step, ExecutionStatus.FAILED, output_data=None, error=error)
        self._emitter.emit(
            "agent_failed",
            f"{role_name(role_id)}: {error}",
            level=LogLevel.ERROR,
            agent_id=role_id,
            step=open_step["step"],
            agent_execution_id=row.id,
            data={
                "agent_name": role_name(role_id),
                "agent_execution_id": str(row.id),
                "error": error,
                "attempt": row.attempt,
            },
        )

    # ------------------------------------------------------------ artifacts

    def on_knowledge(self, artifacts: KnowledgeArtifacts, reused: bool, version: int) -> None:
        self._emitter.emit(
            "knowledge_ready",
            f"Knowledge {'reused' if reused else 'compiled'}: "
            f"{len(artifacts.evidence.entries)} facts the copy may claim, "
            f"{len(artifacts.gaps.unanswered)} gap(s)",
            agent_id="knowledge_compiler",
            data={
                "reused": reused,
                "version": version,
                "evidence_count": len(artifacts.evidence.entries),
                "segments": [segment.name for segment in artifacts.audience.segments],
                "gaps": [gap.missing for gap in artifacts.gaps.unanswered],
                "voice_learned": artifacts.voice.learned,
                # What the compile could not use, and why. A thin ledger has
                # two very different causes - a business with little to say,
                # or a page whose quotes would not verify because the crawler
                # got a JavaScript shell - and they need opposite responses
                # from the user. These were written onto the artifacts and
                # read by nothing.
                "notes": list(artifacts.notes),
            },
        )

    def on_brief(self, brief: CampaignBrief) -> None:
        self._emitter.emit(
            "brief_ready",
            f"Campaign brief: {brief.promise or brief.interpretation}",
            agent_id="strategist",
            data={
                "reader": brief.reader,
                "reader_segment": brief.reader_segment,
                "promise": brief.promise,
                "arc": brief.arc,
                "emails": [
                    {
                        "position": item.position,
                        "job": item.job,
                        "single_idea": item.single_idea,
                        "objection": item.objection,
                        "evidence_ids": item.evidence_ids,
                        "must_not_say": item.must_not_say,
                        # The argument, not only the claim. `single_idea` is
                        # what the email asserts; these four are why anybody
                        # should care, and a timeline that shows the first
                        # without the others cannot say whether the brief was
                        # the problem.
                        "felt_need": item.felt_need,
                        "status_quo": item.status_quo,
                        "why_it_fails": item.why_it_fails,
                        "mechanism": item.mechanism,
                        "call_to_action": item.call_to_action,
                        "next_step_decision": item.next_step_decision,
                        "next_step_value": item.next_step_value,
                        "next_step_evidence_ids": item.next_step_evidence_ids,
                        "next_step_limit": item.next_step_limit,
                        "alternative_arguments": [
                            argument.model_dump() for argument in item.alternative_arguments
                        ],
                    }
                    for item in brief.emails
                ],
            },
        )

    def on_draft(self, position: int, attempt: int, email: Email) -> None:
        """Every draft the writer produced, in full, including the candidates
        that lost the bake-off.

        This hook existed and was not implemented, so the only trace a rewrite
        left was its subject line in a summary. That makes the one question
        worth asking about a run - what changed between attempt 2 and attempt
        3, and did it help - unanswerable from the timeline, which is where
        four rewrites can circle back to a draft that was already read and
        discarded without anybody noticing.
        """
        self._emitter.emit(
            "draft",
            f'Email {position}, draft {attempt}: "{email.subject}"',
            agent_id="email_writer",
            data={
                "position": position,
                "attempt": attempt,
                "subject": email.subject,
                "preview_text": email.preview_text,
                "greeting": email.greeting,
                "body": email.body,
                "call_to_action": email.call_to_action,
                "sign_off": email.sign_off,
                "postscript": email.postscript,
                "word_count": len(email.body.split()),
            },
        )

    def on_repair(self, position: int, repair: int, reason: str) -> None:
        self._emitter.emit(
            "repair",
            f"Email {position}: the draft could not be sent as written "
            f"(repair {repair}) - {reason}",
            level=LogLevel.WARNING,
            agent_id="email_writer",
            data={"position": position, "repair": repair, "reason": reason},
        )

    def on_gates(self, position: int, attempt: int, report: GateReport) -> None:
        if not report.issues:
            self._emitter.emit(
                "gates",
                f"Email {position}: every automatic check passed",
                level=LogLevel.DEBUG,
                agent_id="email_writer",
                data={"position": position, "attempt": attempt, "passed": True},
            )
            return
        self._emitter.emit(
            "gates",
            f"Email {position}: {len(report.blocking)} automatic check(s) failed - "
            + "; ".join(issue.detail for issue in report.blocking[:2]),
            level=LogLevel.WARNING if report.blocking else LogLevel.DEBUG,
            agent_id="email_writer",
            data={
                "position": position,
                "attempt": attempt,
                "passed": report.passed,
                "issues": [
                    {"gate": issue.gate, "detail": issue.detail, "severity": issue.severity.value}
                    for issue in report.issues
                ],
            },
        )

    def on_read(self, position: int, attempt: int, read: PanelRead) -> None:
        primary = read.primary
        # Mapped onto the "review" event the live view already understands:
        # a cold reader's pull is the closest thing this architecture has to a
        # conversion score, and it is a far better one.
        #
        # `readers` carries the whole panel. The flat fields beside it are one
        # reader's answers and are kept for the timeline reducer that already
        # reads them; a run with three readers used to report the panel's
        # score next to the first reader's verdict, and drop the other two
        # entirely - which is the variance the panel is bought for.
        self._emitter.emit(
            "review",
            (
                f"Email {position} read cold: {read.verdict_line()}"
                if not read.understood
                else f"Email {position} read cold: {read.pull:.0f}/10 - {read.verdict_line()}"
            ),
            agent_id="blind_reader",
            data={
                "approved": read.landed,
                "conversion_score": round(read.pull),
                # Whether the panel could say what the email sold, beside the
                # score rather than folded into it. A timeline row showing
                # "3/10" for copy nobody could decode reports the wrong
                # problem: the number is an estimate of what people do with an
                # email they understood.
                "understood": read.understood,
                "summary": primary.what_it_sells,
                "issues": primary.fixes,
                "position": position,
                "attempt": attempt,
                "biggest_doubt": primary.biggest_doubt,
                "stopped_at": primary.stopped_at,
                "readers": [
                    {
                        "persona": item.persona,
                        "reported": item.reported,
                        "opened": item.opened,
                        "pull": item.pull,
                        "would_act": item.would_act,
                        "what_it_sells": item.what_it_sells,
                        "understood": item.understood,
                        "biggest_doubt": item.biggest_doubt,
                        "stopped_at": item.stopped_at,
                        "fixes": item.fixes,
                    }
                    for item in read.reads
                ],
            },
        )

    def on_critique(self, position: int, attempt: int, critique: Critique) -> None:
        self._emitter.emit(
            "critique",
            f"Email {position}: critic says {critique.verdict}"
            + (f" - {critique.summary}" if critique.summary else ""),
            agent_id="conversion_critic",
            data={
                "position": position,
                "attempt": attempt,
                "verdict": critique.verdict,
                "failure_mode": critique.failure_mode,
                "strategy_gap": critique.strategy_gap,
                "brief_drift": critique.brief_drift,
                "unspent_evidence": critique.unspent_evidence,
                "critique_summary": critique.summary,
                "edits": [
                    {
                        "line": edit.line,
                        "problem": edit.problem,
                        "fix": edit.fix,
                        "severity": edit.severity,
                    }
                    for edit in critique.edits
                ],
            },
        )

    def on_email_accepted(self, position: int, version: EmailVersion) -> None:
        agent_id = self.writer_rows.get(position)
        if agent_id is not None and not version.gates.blocking:
            stored = dict(self._execution.result or {})
            checkpoints = dict(stored.get("accepted_checkpoints", {}))
            checkpoints[str(position)] = {
                "email": version.email.model_dump(mode="json"),
                "agent_execution_id": str(agent_id),
                "pull": version.read.pull,
            }
            self._execution.result = {**stored, "accepted_checkpoints": checkpoints}
            self._orchestrator._campaign_executions.update(self._execution)
        self._emitter.emit(
            "email_ready",
            f'Email {position} ready: "{version.email.subject}" ({version.describe()})',
            agent_id="email_writer",
            data={
                "position": position,
                "subject": version.email.subject,
                "pull": version.read.pull,
                "attempts": version.attempt,
                "clean": not version.gates.blocking,
            },
        )

    def on_sequence(self, report: SequenceReport) -> None:
        self._emitter.emit(
            "sequence_review",
            report.render(),
            agent_id="sequence_reviewer",
            data={
                "passed": report.passed,
                "rework": {str(key): value for key, value in report.rework.items()},
                "summary": report.verdict.summary,
            },
        )

    def on_report(self, report: CampaignReport) -> None:
        self._emitter.emit(
            "campaign_report",
            report.render(),
            data={
                "delivered": report.delivered,
                "promised": report.promised,
                "average_pull": round(report.average_pull, 1),
                "contract_violations": report.contract_violations,
                "limiting_gaps": report.limiting_gaps,
                "below_floor": [line.position for line in report.below_floor],
                "what_would_help_most": report.what_would_help_most,
            },
        )

    # ------------------------------------------------------------- internals

    def _close(self) -> dict[str, Any] | None:
        open_step, self._open = self._open, None
        return open_step

    def _persist_row(
        self,
        open_step: dict[str, Any],
        status: ExecutionStatus,
        output_data: dict[str, Any] | None,
        error: str | None,
    ) -> AgentExecution:
        calls, self._calls = self._calls, []
        role_id = open_step["role_id"]
        return self._orchestrator._agent_executions.create(
            AgentExecution(
                campaign_execution_id=self._execution.id,
                agent_id=role_id,
                agent_name=role_name(role_id),
                sequence_order=open_step["step"],
                status=status,
                input_data={"label": open_step["label"], **open_step["data"]},
                output_data=output_data,
                error_message=error,
                started_at=open_step["started_at"],
                completed_at=datetime.now(UTC),
                model=calls[-1].model if calls else None,
                input_tokens=sum(call.input_tokens for call in calls),
                output_tokens=sum(call.output_tokens for call in calls),
                cache_creation_input_tokens=sum(
                    call.cache_creation_input_tokens for call in calls
                ),
                cache_read_input_tokens=sum(call.cache_read_input_tokens for call in calls),
                cost_usd=round(sum(call.cost_usd for call in calls), 6),
                duration_ms=sum(call.duration_ms for call in calls),
                attempt=self.attempts.get(role_id, 1),
            )
        )


class CampaignOrchestrator:
    """Thin persistence adapter around the campaign pipeline.

    It makes NO decisions about what runs: it creates the execution row, hands
    the request and the business's knowledge to the pipeline, persists every
    role run, deliverable and log line, and finalizes the execution row. All
    the reasoning lives in app.marketing.pipeline.

    `create_execution` and `execute` are split so a caller that needs the
    execution row back immediately (the async /start endpoint - see
    app.orchestration.execution_manager) can do so without waiting for the run
    to finish; `run` is the two combined, for direct/synchronous callers such
    as the test suite.
    """

    def __init__(self, session: Session, ai_provider: AIProvider) -> None:
        self._session = session
        self._campaign_executions = CampaignExecutionRepository(session)
        self._agent_executions = AgentExecutionRepository(session)
        self._generated_assets = GeneratedAssetRepository(session)
        self._logs = ExecutionLogRepository(session)
        self._ai_provider = ai_provider

    def _usable_after_close(self, execution: CampaignExecution) -> CampaignExecution:
        """Reload an execution the caller will keep using once this session is
        gone.

        Emitting an event writes a log row, and that commit expires every
        other instance in the session - including the execution being
        returned. Callers such as execution_manager.launch read its id after
        the `with Session(...)` block has closed, where an expired instance
        can no longer refresh itself and raises DetachedInstanceError.
        """
        self._session.refresh(execution)
        return execution

    def _emitter_for(self, execution_id: UUID) -> ExecutionEventEmitter:
        from sqlalchemy import func

        from app.models.execution_log import ExecutionLog
        highest = self._session.exec(select(func.max(ExecutionLog.sequence)).where(
            ExecutionLog.campaign_execution_id == execution_id
        )).one()
        broker.resume_sequence(execution_id, highest or 0)
        return ExecutionEventEmitter(self._logs, execution_id)

    def create_execution(
        self,
        campaign: Campaign,
        *,
        recommendation_snapshot: dict | None = None,
        generated_despite_recommendation: bool = False,
    ) -> CampaignExecution:
        execution = self._campaign_executions.create(
            CampaignExecution(
                campaign_id=campaign.id,
                status=ExecutionStatus.RUNNING,
                started_at=datetime.now(UTC),
                recommendation_snapshot=recommendation_snapshot,
                generated_despite_recommendation=generated_despite_recommendation,
            )
        )
        self._emitter_for(execution.id).emit(
            "execution_started",
            f"Request: {campaign.request}",
            data={"campaign_id": str(campaign.id), "request": campaign.request},
        )
        return self._usable_after_close(execution)

    async def run(
        self, campaign: Campaign, cancel_token: CancellationToken | None = None
    ) -> CampaignExecution:
        execution = self.create_execution(campaign)
        return await self.execute(campaign, execution, cancel_token=cancel_token)

    async def execute(
        self,
        campaign: Campaign,
        execution: CampaignExecution,
        cancel_token: CancellationToken | None = None,
    ) -> CampaignExecution:
        emitter = self._emitter_for(execution.id)
        observer = _PersistenceObserver(self, execution, emitter)
        policy = resolve_policy(
            (campaign.policy or {}).get("preset"),
            {k: v for k, v in (campaign.policy or {}).items() if k != "preset"} or None,
        )
        events = EventBus()
        _bridge_runtime_events(events, emitter)

        session = ModelSession(
            provider=self._ai_provider,
            prompt_engine=get_prompt_engine(PROMPTS_DIR),
            events=events,
            model_router=ModelRouter(_resolve_overrides(policy, campaign)),
            execution_id=str(execution.id),
            on_call=observer.record_call,
        )
        pipeline = EmailCampaignPipeline(
            session=session,
            knowledge=_DbKnowledgeGateway(self._session, campaign),
            policy=policy,
            observer=observer,
            cancel_token=cancel_token,
            deadline=(
                time.monotonic() + policy.max_duration_seconds
                if policy.max_duration_seconds is not None
                else None
            ),
        )
        request = CampaignRequest(
            name=campaign.name,
            request=campaign.request,
            product_description=campaign.product_description,
            product_url=campaign.product_url,
            target_market=campaign.target_market,
            goals=campaign.goals,
            sender_name=campaign.sender_name or "",
            sender_role=campaign.sender_role or "",
            cta_url=campaign.cta_url,
            # Validated here rather than trusted: the column is JSON, and a
            # channel the pipeline cannot read would fix the contract to a
            # deliverable nothing knows how to write.
            channel=LinkedInChannel.model_validate(campaign.channel) if campaign.channel else None,
        )

        try:
            result = await pipeline.run(request)
        except Exception as exc:
            from app.orchestration.checkpoints import recover_accepted_emails

            logger.exception("campaign run crashed")
            emitter.current_step = None
            delivered = recover_accepted_emails(self._session, execution)
            execution.status = ExecutionStatus.COMPLETED if delivered else ExecutionStatus.FAILED
            execution.result = {
                **(execution.result or {}),
                "run_status": "degraded" if delivered else "failed",
            }
            execution.error_message = str(exc)
            execution.total_input_tokens = session.usage.billable_input_tokens
            execution.total_output_tokens = session.usage.output_tokens
            execution.total_cache_read_tokens = session.usage.cache_read_input_tokens
            execution.estimated_cost_usd = round(session.usage.cost_usd, 4)
            execution.completed_at = datetime.now(UTC)
            self._campaign_executions.update(execution)
            emitter.emit(
                "execution_finished",
                f"Campaign run interrupted: {exc}",
                level=LogLevel.ERROR,
                data={"status": execution.status.value, "run_status": execution.result["run_status"],
                      "delivered": delivered, "error": str(exc)},
            )
            broker.close(execution.id)
            return self._usable_after_close(execution)

        emitter.current_step = None
        self._persist_assets(campaign, execution, result, observer)
        self._finalize(execution, result)
        emitter.emit(
            "execution_finished",
            f"Campaign run finished: {result.status}",
            data={
                "status": execution.status.value,
                "run_status": result.status,
                "estimated_cost_usd": execution.estimated_cost_usd,
                "delivered": result.deliverables,
            },
        )
        broker.close(execution.id)
        return self._usable_after_close(execution)

    # ------------------------------------------------------------- internals

    def _persist_assets(
        self,
        campaign: Campaign,
        execution: CampaignExecution,
        result: CampaignRunResult,
        observer: _PersistenceObserver,
    ) -> None:
        """One row per email, written once the run is over.

        Deliberately not written as each draft lands: an email is rewritten up
        to three times and reworked again by the sequence pass, and persisting
        every version as a deliverable would hand the user four copies of the
        same email to choose between. The versions are in the timeline; the
        clipboard gets the one that won.
        """
        fallback = next(iter(observer.writer_rows.values()), None)
        if result.message is not None:
            self._persist_message(execution, result, fallback)
            return
        tier, brand = self._presentation(campaign)
        for outcome in result.outcomes:
            email: Email = outcome.email
            agent_execution_id = observer.writer_rows.get(email.position, fallback)
            if agent_execution_id is None:
                logger.warning("no agent execution row to attach email %d to", email.position)
                continue
            style = style_for_action(
                brand, explicit_url=campaign.cta_url,
                planned_action=outcome.selected_brief.call_to_action,
                offer=result.artifacts.offer if result.artifacts else None,
                licensed_urls=(
                    [entry.source for entry in result.artifacts.evidence.entries]
                    if result.artifacts else []
                ),
            )
            self._generated_assets.create(
                GeneratedAsset(
                    campaign_execution_id=execution.id,
                    agent_execution_id=agent_execution_id,
                    asset_type=AssetType.EMAIL,
                    title=email.subject,
                    content=text_alternative(email, style),
                    content_html=_html_or_none(email, tier, style),
                    position=email.position,
                    asset_metadata={
                        **email.model_dump(mode="json"),
                        "pull": outcome.best.read.pull,
                        "revisions": len(outcome.versions) - 1,
                        "single_idea": outcome.selected_brief.single_idea,
                        "evidence_ids": outcome.selected_brief.evidence_ids,
                        "tier": tier.value,
                        "sequence_review_pending": result.sequence is None and bool(result.abort_reason),
                    },
                )
            )

    def _persist_message(
        self,
        execution: CampaignExecution,
        result: CampaignRunResult,
        agent_execution_id: UUID | None,
    ) -> None:
        """The LinkedIn deliverable: the text, and what it cost the writer to
        stay inside the limit. No HTML - this is pasted into a message box."""
        message = result.message or {}
        if agent_execution_id is None:
            logger.warning("no agent execution row to attach the LinkedIn message to")
            return
        brief = result.brief.emails[0] if result.brief and result.brief.emails else None
        self._generated_assets.create(
            GeneratedAsset(
                campaign_execution_id=execution.id,
                agent_execution_id=agent_execution_id,
                asset_type=AssetType.LINKEDIN_MESSAGE,
                title=f"LinkedIn {message.get('kind', 'message')} to "
                f"{message.get('recipient_name', 'them')}",
                content=message.get("body", ""),
                position=1,
                asset_metadata={
                    **message,
                    "single_idea": brief.single_idea if brief else "",
                    "evidence_ids": brief.evidence_ids if brief else [],
                },
            )
        )

    def _presentation(self, campaign: Campaign) -> tuple[EmailTier, BrandStyle]:
        """How this campaign's emails should look.

        Plain by default, and deliberately: these are mostly cold sales
        sequences, where a branded template reads as a mailshot, scores worse
        with filters and converts worse than a message that looks like it came
        from a person. A campaign asks for the branded tier explicitly, and
        only a campaign attached to a brand has anything to brand it with.

        The CTA URL is the one field here the campaign may override, because
        it is the one that changes per campaign: a launch points at the launch
        page and a cart recovery points at the cart. The brand's own website
        is the fallback, which is right far more often than nothing is - and
        nothing is still the answer when neither exists, since the renderer
        would otherwise draw a button to a page that does not exist.
        """
        requested = (campaign.policy or {}).get("email_tier")
        tier = EmailTier.BRANDED if requested == EmailTier.BRANDED else EmailTier.PLAIN
        if campaign.brand_id is None:
            return tier, BrandStyle(cta_url=campaign.cta_url or "")
        brand = BrandRepository(self._session).get(campaign.brand_id)
        if brand is None:
            return tier, BrandStyle(cta_url=campaign.cta_url or "")
        return tier, BrandStyle(
            name=brand.name,
            logo_url=brand.logo_url or "",
            primary_color=brand.primary_color or BrandStyle.primary_color,
            footer_lines=tuple(brand.footer_lines or ()),
            cta_url=campaign.cta_url or brand.website_url or "",
            unsubscribe_url=brand.unsubscribe_url or "",
        )

    def _finalize(self, execution: CampaignExecution, result: CampaignRunResult) -> None:
        if result.status == "cancelled":
            execution.status = ExecutionStatus.CANCELLED
            execution.error_message = result.abort_reason
        elif result.status in _DELIVERING_STATUSES and result.delivered:
            execution.status = ExecutionStatus.COMPLETED
            # A degraded run still delivered: keep the caveat, drop any stale
            # failure the startup reaper may have written onto this row.
            execution.error_message = (
                result.abort_reason if result.status != "completed" else None
            )
        elif result.status == "needs_input":
            # Not a crash and not a delivery: the run stopped on purpose,
            # before spending anything, because the material could not carry a
            # campaign. There is no lifecycle status for "asked a question", so
            # it lands on FAILED - but the message is the questions, not a
            # stack trace, and `report.questions` carries them structured.
            execution.status = ExecutionStatus.FAILED
            execution.error_message = "\n".join(
                [result.abort_reason or "", *result.report.questions]
            ).strip()
        else:
            execution.status = ExecutionStatus.FAILED
            execution.error_message = (
                result.abort_reason or f"Campaign run ended: {result.status}"
            )

        execution.completed_at = datetime.now(UTC)
        execution_result = {
            "run_status": result.status,
            "report": result.report.model_dump(mode="json"),
            "brief": result.brief.model_dump(mode="json") if result.brief else None,
            "knowledge_version": result.artifacts.version if result.artifacts else 0,
            "recommendation_at_generation": execution.recommendation_snapshot,
            "generated_despite_recommendation": (
                execution.generated_despite_recommendation
            ),
        }
        if result.intelligence is not None:
            execution_result["intelligence"] = result.intelligence.model_dump(mode="json")
        execution.result = execution_result
        # Every input token the run consumed, cached input included - that is
        # what the user's quota paid for, and recording only the uncached
        # remainder is what made every earlier run look ~40% cheaper than it
        # was. Cost is summed per call, where the provider's own figure was
        # already preferred over our price table (see usage_cost_usd).
        execution.total_input_tokens = result.usage.billable_input_tokens
        execution.total_output_tokens = result.usage.output_tokens
        execution.total_cache_read_tokens = result.usage.cache_read_input_tokens
        execution.estimated_cost_usd = round(result.usage.cost_usd, 4)
        self._campaign_executions.update(execution)


def _html_or_none(email: Email, tier: EmailTier, brand: BrandStyle) -> str | None:
    """The rendered email, or nothing at all.

    Rendering is presentation, and the deliverable is `content` - the text the
    user pastes. A campaign that spent thirteen minutes and real money writing
    three good emails must not be reported as failed because a logo URL had a
    character in it that something did not like. Anything that goes wrong here
    costs the HTML and nothing else.
    """
    try:
        rendered = render_html(email, tier, brand)
    except Exception:
        logger.warning("could not render email %d as HTML", email.position, exc_info=True)
        return None
    size = len(rendered.encode("utf-8"))
    if size > MAX_EMAIL_BYTES:
        # Gmail clips past this and hides everything below the fold, which in
        # an email is usually the call to action.
        logger.warning(
            "email %d renders to %d bytes, past the %d clipping limit - keeping text only",
            email.position,
            size,
            MAX_EMAIL_BYTES,
        )
        return None
    return rendered


def _resolve_overrides(policy: ExecutionPolicy, campaign: Campaign) -> dict[str, str]:
    """The model map this run routes on: the preset's, then the operator's.

    A plain merge is wrong in one case, and it is the case the picker exists
    for. `ModelRouter` checks an exact role id before it looks at the wildcard,
    and the `maximum` preset ships per-role overrides for the five craft roles.
    So an operator who chose "every agent -> GPT" on that preset would get a
    run where the strategist, writer, critic, sequence reviewer and subject
    writer all quietly stayed on Opus - the five roles they most likely meant.
    Nothing would say so; the picker would show GPT and the receipt would show
    Claude.

    A wildcard the operator set is a statement about the whole run, so it
    displaces the preset's suggestions entirely. Their own per-agent pins are
    applied on top and still win, which is exactly what the panel promises.
    """
    overrides: dict[str, str] = {} if WILDCARD_ROLE in (
        campaign.model_overrides or {}
    ) else dict(policy.model_overrides)
    overrides.update(campaign.model_overrides or {})
    return overrides


def _bridge_runtime_events(events: EventBus, emitter: ExecutionEventEmitter) -> None:
    """Forward the model session's own event bus onto the execution's stream.

    These are the events that fill the long silence of a single `generate()`
    call, which is most of what a campaign spends its time on. Everything here
    is progress, not history: DEBUG level, so the activity log stays readable
    while the live view still gets a heartbeat.
    """

    def on_model_call_started(event: ModelCallStarted) -> None:
        emitter.emit(
            "model_call_started",
            f"Sent {event.prompt_chars:,} characters to {event.model} - waiting for the answer",
            level=LogLevel.DEBUG,
            agent_id=event.agent_id,
            data={"model": event.model, "prompt_chars": event.prompt_chars},
        )

    def on_model_call_retried(event: ModelCallRetried) -> None:
        # WARNING, not DEBUG: everything else on this bridge is progress a
        # healthy run also produces, and this is the one line that says the
        # run is in trouble. A retry that scrolls past with the heartbeat is
        # a retry nobody sees.
        emitter.emit(
            "model_call_retried",
            f"{event.model} did not answer (attempt {event.attempt}: {event.error}) - "
            "sending it again",
            level=LogLevel.WARNING,
            agent_id=event.agent_id,
            data={"model": event.model, "attempt": event.attempt, "error": event.error},
        )

    def on_model_call_finished(event: ModelCallFinished) -> None:
        emitter.emit(
            "model_call_finished",
            f"{event.model} answered with {event.response_chars:,} characters "
            f"in {event.duration_ms / 1000:.1f}s "
            f"({event.billable_input_tokens:,} in / {event.output_tokens:,} out)",
            level=LogLevel.DEBUG,
            agent_id=event.agent_id,
            data={
                "model": event.model,
                "input_tokens": event.billable_input_tokens,
                "output_tokens": event.output_tokens,
                "cache_read_input_tokens": event.cache_read_input_tokens,
                "cost_usd": round(event.cost_usd, 6),
                "duration_ms": event.duration_ms,
                "response_chars": event.response_chars,
            },
        )

    events.subscribe(ModelCallStarted, on_model_call_started)
    events.subscribe(ModelCallRetried, on_model_call_retried)
    events.subscribe(ModelCallFinished, on_model_call_finished)


# ───────────────────────────────────────────────── stepped execution ────────
#
#  A stepped run (see app.orchestration.stepped_runner) builds exactly the same
#  pipeline as `CampaignOrchestrator.execute`, once per step, in a process that
#  has never seen the run before. These two functions are that construction and
#  that persistence, reachable without the orchestrator instance - so there is
#  one definition of how a run is wired and not a second one that drifts.


def build_stepped_pipeline(
    session: Session,
    campaign: Campaign,
    execution: CampaignExecution,
    ai_provider: AIProvider,
) -> tuple[EmailCampaignPipeline, CampaignRequest, "_PersistenceObserver"]:
    """The pipeline, the request and the observer for one step of a run.

    The handler's DurablePermit checks the persisted campaign deadline and
    cancellation before every model call, across all Lambda invocations.
    """
    from app.models.campaign_run_state import CampaignRunState

    state = session.exec(select(CampaignRunState).where(
        CampaignRunState.execution_id == execution.id
    )).first()
    if state is not None and state.request_snapshot:
        campaign = Campaign.model_validate(state.request_snapshot)
    orchestrator = CampaignOrchestrator(session, ai_provider)
    emitter = orchestrator._emitter_for(execution.id)
    observer = _PersistenceObserver(orchestrator, execution, emitter)
    from sqlalchemy import func
    observer._step = session.exec(select(func.max(AgentExecution.sequence_order)).where(
        AgentExecution.campaign_execution_id == execution.id
    )).one() or 0
    policy = resolve_policy(
        (campaign.policy or {}).get("preset"),
        {k: v for k, v in (campaign.policy or {}).items() if k != "preset"} or None,
    )
    events = EventBus()
    _bridge_runtime_events(events, emitter)

    def record_stepped_call(call):
        observer.record_call(call)
        if state is not None and state.request_snapshot:
            from sqlalchemy import update
            session.execute(update(CampaignExecution).where(CampaignExecution.id == execution.id).values(
                total_input_tokens=CampaignExecution.total_input_tokens + call.billable_input_tokens,
                total_output_tokens=CampaignExecution.total_output_tokens + call.output_tokens,
                total_cache_read_tokens=CampaignExecution.total_cache_read_tokens + call.cache_read_input_tokens,
                estimated_cost_usd=CampaignExecution.estimated_cost_usd + call.cost_usd,
            ))
            session.commit()

    model_session = ModelSession(
        provider=orchestrator._ai_provider,
        prompt_engine=get_prompt_engine(PROMPTS_DIR),
        events=events,
        model_router=ModelRouter(_resolve_overrides(policy, campaign)),
        execution_id=str(execution.id),
        on_call=record_stepped_call,
    )
    if state is not None and state.request_snapshot:
        model_session.usage.input_tokens = execution.total_input_tokens - execution.total_cache_read_tokens
        model_session.usage.cache_read_input_tokens = execution.total_cache_read_tokens
        model_session.usage.output_tokens = execution.total_output_tokens
        model_session.usage.cost_usd = execution.estimated_cost_usd
    pipeline = EmailCampaignPipeline(
        session=model_session,
        knowledge=_DbKnowledgeGateway(session, campaign),
        policy=policy,
        observer=observer,
        cancel_token=None,
        deadline=None,
    )
    request = CampaignRequest(
        name=campaign.name,
        request=campaign.request,
        product_description=campaign.product_description,
        product_url=campaign.product_url,
        target_market=campaign.target_market,
        goals=campaign.goals,
        sender_name=campaign.sender_name or "",
        sender_role=campaign.sender_role or "",
        cta_url=campaign.cta_url,
        channel=LinkedInChannel.model_validate(campaign.channel) if campaign.channel else None,
    )
    return pipeline, request, observer



def rehydrate_writer_rows(
    session: Session, execution: CampaignExecution, observer: "_PersistenceObserver"
) -> None:
    """Rebuild the position → writer-row map from the database.

    `_persist_assets` needs an `agent_execution_id` for every deliverable, and
    in an in-process run the observer collected those as the writer finished
    each email. A stepped run's finish step is a different process with a fresh
    observer that saw none of them - so without this every asset would have no
    row to hang off and the run would hand over nothing.

    The rows themselves are already in the database; each craft step wrote its
    own. Only the in-memory index has to be rebuilt.
    """
    rows = session.exec(
        select(AgentExecution)
        .where(AgentExecution.campaign_execution_id == execution.id)
        .where(AgentExecution.agent_id == "email_writer")
        .order_by(AgentExecution.sequence_order)
    ).all()
    for row in rows:
        position = (row.input_data or {}).get("position")
        if position is not None:
            observer.writer_rows[int(position)] = row.id

def persist_stepped_result(
    session: Session,
    campaign: Campaign,
    execution: CampaignExecution,
    result: CampaignRunResult,
    observer: "_PersistenceObserver",
    ai_provider: AIProvider,
) -> CampaignExecution:
    """Close a stepped run exactly as `execute` closes an in-process one."""
    orchestrator = CampaignOrchestrator(session, ai_provider)
    emitter = orchestrator._emitter_for(execution.id)
    emitter.current_step = None
    orchestrator._persist_assets(campaign, execution, result, observer)
    orchestrator._finalize(execution, result)
    emitter.emit(
        "execution_finished",
        f"Campaign run finished: {result.status}",
        data={
            "status": execution.status.value,
            "run_status": result.status,
            "estimated_cost_usd": execution.estimated_cost_usd,
            "delivered": result.deliverables,
        },
    )
    broker.close(execution.id)
    return orchestrator._usable_after_close(execution)
