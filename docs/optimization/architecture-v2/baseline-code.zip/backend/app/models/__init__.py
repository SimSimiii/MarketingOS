"""SQLModel table models.

Importing every model module here ensures they are registered on
SQLModel.metadata before `init_db()` / Alembic autogenerate run.
"""

from app.models.admin import AdminAuditLog, AdminUser
from app.models.agent_execution import AgentExecution
from app.models.auth_rate_limit import AuthRateLimit
from app.models.brand import Brand
from app.models.campaign import Campaign
from app.models.campaign_execution import CampaignExecution
from app.models.campaign_run_state import CampaignRunState
from app.models.credit import (
    CreditAccount,
    CreditCheckout,
    CreditTransaction,
    ReversedStripePayment,
)
from app.models.email_analysis import EmailAnalysis
from app.models.enums import (
    AdminRole,
    AssetType,
    ExecutionStatus,
    LogLevel,
    UserPlan,
    UserRole,
    UserStatus,
)
from app.models.execution_log import ExecutionLog
from app.models.generated_asset import GeneratedAsset
from app.models.knowledge_artifacts import KnowledgeArtifactSet
from app.models.knowledge_document import KnowledgeDocument
from app.models.linkedin import LinkedInRun
from app.models.market import (
    AudienceMapRow,
    AudienceResearchRow,
    MarketScan,
    ProductCapabilityProfileRow,
    ProofCandidateRow,
    ProspectRow,
    RadarEventRow,
    RelevanceDossierRow,
    Rival,
    UserAudienceRow,
)
from app.models.user import User, UserSession
from app.models.user_settings import UserSettings

__all__ = [
    "AdminAuditLog",
    "AdminRole",
    "AdminUser",
    "AgentExecution",
    "AssetType",
    "AudienceMapRow",
    "AudienceResearchRow",
    "AuthRateLimit",
    "Brand",
    "Campaign",
    "CampaignExecution",
    "CampaignRunState",
    "CreditAccount",
    "CreditCheckout",
    "CreditTransaction",
    "EmailAnalysis",
    "ExecutionLog",
    "ExecutionStatus",
    "GeneratedAsset",
    "KnowledgeArtifactSet",
    "KnowledgeDocument",
    "LinkedInRun",
    "LogLevel",
    "MarketScan",
    "ProductCapabilityProfileRow",
    "ProofCandidateRow",
    "ProspectRow",
    "RadarEventRow",
    "RelevanceDossierRow",
    "ReversedStripePayment",
    "Rival",
    "User",
    "UserAudienceRow",
    "UserPlan",
    "UserRole",
    "UserSession",
    "UserSettings",
    "UserStatus",
]

from app.models.background_job import BackgroundJob  # noqa: F401
